const mongoose = require('mongoose');

const ecoScoreSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  overallScore: {
    type: Number,
    required: true,
    min: 0,
    max: 100
  },
  categoryScores: {
    transportation: {
      score: { type: Number, min: 0, max: 100 },
      details: {
        carMiles: Number,
        publicTransit: Number,
        walking: Number,
        cycling: Number
      }
    },
    diet: {
      score: { type: Number, min: 0, max: 100 },
      details: {
        meatConsumption: Number,
        dairyConsumption: Number,
        localFood: Number,
        organicFood: Number
      }
    },
    energy: {
      score: { type: Number, min: 0, max: 100 },
      details: {
        electricityUsage: Number,
        renewableEnergy: Number,
        heatingCooling: Number
      }
    },
    waste: {
      score: { type: Number, min: 0, max: 100 },
      details: {
        recycling: Number,
        composting: Number,
        singleUsePlastics: Number
      }
    },
    water: {
      score: { type: Number, min: 0, max: 100 },
      details: {
        dailyUsage: Number,
        conservation: Number
      }
    }
  },
  carbonFootprint: {
    daily: Number,
    weekly: Number,
    monthly: Number,
    yearly: Number
  },
  recommendations: [{
    category: String,
    tip: String,
    impact: {
      type: String,
      enum: ['Low', 'Medium', 'High']
    },
    effort: {
      type: String,
      enum: ['Low', 'Medium', 'High']
    },
    implemented: {
      type: Boolean,
      default: false
    }
  }],
  goals: [{
    category: String,
    target: Number,
    current: Number,
    deadline: Date,
    completed: {
      type: Boolean,
      default: false
    }
  }],
  timestamp: {
    type: Date,
    default: Date.now
  }
}, {
  timestamps: true
});

// Index for efficient queries
ecoScoreSchema.index({ userId: 1, timestamp: -1 });
ecoScoreSchema.index({ userId: 1, overallScore: -1 });

module.exports = mongoose.model('EcoScore', ecoScoreSchema); 