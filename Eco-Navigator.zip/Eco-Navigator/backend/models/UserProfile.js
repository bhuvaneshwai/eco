const mongoose = require('mongoose');

const userProfileSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
    unique: true
  },
  sustainabilityPreferences: {
    transportation: {
      preferredMode: {
        type: String,
        enum: ['car', 'public_transit', 'walking', 'cycling', 'mixed'],
        default: 'mixed'
      },
      carpooling: {
        type: Boolean,
        default: false
      },
      electricVehicle: {
        type: Boolean,
        default: false
      }
    },
    diet: {
      type: {
        type: String,
        enum: ['omnivore', 'vegetarian', 'vegan', 'pescatarian'],
        default: 'omnivore'
      },
      localFood: {
        type: Boolean,
        default: false
      },
      organicFood: {
        type: Boolean,
        default: false
      }
    },
    energy: {
      renewableEnergy: {
        type: Boolean,
        default: false
      },
      energyEfficient: {
        type: Boolean,
        default: false
      }
    },
    waste: {
      recycling: {
        type: Boolean,
        default: false
      },
      composting: {
        type: Boolean,
        default: false
      },
      zeroWaste: {
        type: Boolean,
        default: false
      }
    }
  },
  goals: {
    carbonReduction: {
      target: Number, // kg CO2 per year
      current: Number,
      deadline: Date
    },
    ecoScore: {
      target: Number, // 0-100
      current: Number
    },
    activities: {
      target: Number, // number of eco-friendly activities per week
      current: Number
    }
  },
  notifications: {
    weeklyReport: {
      type: Boolean,
      default: true
    },
    goalReminders: {
      type: Boolean,
      default: true
    },
    tips: {
      type: Boolean,
      default: true
    },
    achievements: {
      type: Boolean,
      default: true
    }
  },
  achievements: [{
    type: {
      type: String,
      enum: ['carbon_reduction', 'eco_score', 'streak', 'goal_completion', 'milestone']
    },
    title: String,
    description: String,
    earnedAt: {
      type: Date,
      default: Date.now
    },
    icon: String
  }],
  stats: {
    totalCarbonReduced: {
      type: Number,
      default: 0
    },
    totalActivities: {
      type: Number,
      default: 0
    },
    currentStreak: {
      type: Number,
      default: 0
    },
    longestStreak: {
      type: Number,
      default: 0
    },
    joinDate: {
      type: Date,
      default: Date.now
    }
  }
}, {
  timestamps: true
});

module.exports = mongoose.model('UserProfile', userProfileSchema); 