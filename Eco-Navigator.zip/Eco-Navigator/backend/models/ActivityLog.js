const mongoose = require('mongoose');

const activityLogSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  activityType: {
    type: String,
    required: true,
    enum: ['energy', 'water', 'transport', 'food', 'waste', 'other']
  },
  value: {
    type: Number,
    required: true
  },
  unit: {
    type: String,
    required: true
  },
  carbonFootprint: {
    carbonKg: {
      type: Number,
      required: true
    },
    carbonLb: Number,
    carbonMt: Number
  },
  description: String,
  location: {
    country: String,
    region: String
  },
  metadata: {
    transportMode: {
      type: String,
      enum: ['car', 'bus', 'train', 'plane', 'bike', 'walking', 'other']
    },
    energySource: {
      type: String,
      enum: ['electricity', 'gas', 'renewable', 'other']
    },
    foodType: {
      type: String,
      enum: ['meat', 'dairy', 'vegetables', 'grains', 'other']
    }
  },
  timestamp: {
    type: Date,
    default: Date.now
  }
}, {
  timestamps: true
});

// Index for efficient queries
activityLogSchema.index({ userId: 1, timestamp: -1 });
activityLogSchema.index({ userId: 1, activityType: 1 });

module.exports = mongoose.model('ActivityLog', activityLogSchema); 