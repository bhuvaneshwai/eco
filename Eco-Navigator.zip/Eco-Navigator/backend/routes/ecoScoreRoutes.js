const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/authMiddleware');
const {
  calculateEcoScore,
  getEcoScoreHistory,
  getCurrentEcoScore,
  updateEcoScoreGoals
} = require('../controllers/ecoScoreController');

// All routes require authentication
router.use(protect);

// Calculate and save eco score
router.post('/calculate', calculateEcoScore);

// Get eco score history
router.get('/history', getEcoScoreHistory);

// Get current eco score
router.get('/current', getCurrentEcoScore);

// Update eco score goals
router.put('/goals', updateEcoScoreGoals);

module.exports = router; 