const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/authMiddleware');
const {
  getUserActivities,
  addActivity,
  getActivityStats,
  deleteActivity
} = require('../controllers/activityController');

// All routes require authentication
router.use(protect);

// Get user's activities with pagination and filtering
router.get('/', getUserActivities);

// Add a new activity
router.post('/', addActivity);

// Get activity statistics
router.get('/stats', getActivityStats);

// Delete an activity
router.delete('/:id', deleteActivity);

module.exports = router; 