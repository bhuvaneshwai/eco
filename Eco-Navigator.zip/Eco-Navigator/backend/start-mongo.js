// Helper script to start MongoDB if not running
const { spawn } = require('child_process');
const mongoose = require('mongoose');

async function checkMongoConnection() {
  try {
    await mongoose.connect('mongodb://localhost:27017/test', {
      serverSelectionTimeoutMS: 2000
    });
    await mongoose.disconnect();
    return true;
  } catch (error) {
    return false;
  }
}

async function startMongo() {
  console.log('🔍 Checking if MongoDB is running...');
  
  const isRunning = await checkMongoConnection();
  
  if (isRunning) {
    console.log('✅ MongoDB is already running!');
    return;
  }
  
  console.log('❌ MongoDB is not running. Attempting to start it...');
  
  // Try to start MongoDB service first
  const serviceStart = spawn('net', ['start', 'MongoDB'], { 
    stdio: 'pipe',
    shell: true 
  });
  
  serviceStart.on('close', async (code) => {
    if (code === 0) {
      console.log('✅ MongoDB service started successfully!');
    } else {
      console.log('⚠️  Could not start MongoDB service. Trying manual start...');
      
      // Try to start mongod manually
      const mongodStart = spawn('mongod', ['--dbpath', 'C:\\data\\db'], {
        stdio: 'pipe',
        shell: true,
        detached: true
      });
      
      mongodStart.on('error', (error) => {
        console.error('❌ Failed to start MongoDB manually:', error.message);
        console.log('💡 Please start MongoDB manually using one of these methods:');
        console.log('   1. Run as Administrator: net start MongoDB');
        console.log('   2. Start MongoDB Compass');
        console.log('   3. Run: mongod --dbpath C:\\data\\db');
      });
      
      mongodStart.on('close', (code) => {
        if (code === 0) {
          console.log('✅ MongoDB started manually!');
        }
      });
    }
  });
}

if (require.main === module) {
  startMongo();
}

module.exports = { startMongo, checkMongoConnection }; 