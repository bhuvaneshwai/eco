const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');
const path = require('path');
const connectDB = require('./config/db');
const authRoutes = require('./routes/authRoutes');
const userRoutes = require('./routes/userRoutes');
const activityRoutes = require('./routes/activityRoutes');
const ecoScoreRoutes = require('./routes/ecoScoreRoutes');

// Load environment variables
dotenv.config({ path: path.join(__dirname, '.env') });

// Connect to database
connectDB();

const app = express();

// Middleware
app.use(express.json());

const allowedOrigins = [
  process.env.FRONTEND_URL || 'http://localhost:8080',
  'http://192.168.137.214:8080',
  'http://10.1.51.14:8080'
];

app.use(cors({
  origin: function (origin, callback) {
    console.log(`CORS CHECK: Request from origin: ${origin}`);
    if (!origin || allowedOrigins.indexOf(origin) !== -1) {
      console.log('CORS CHECK: Origin allowed.');
      callback(null, true);
    } else {
      console.log('CORS CHECK: Origin NOT allowed.');
      callback(new Error('Not allowed by CORS'));
    }
  },
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));

// Routes
app.use('/api', authRoutes);
app.use('/api/users', userRoutes);
app.use('/api/activities', activityRoutes);
app.use('/api/eco-scores', ecoScoreRoutes);

// Error handling middleware
app.use((err, req, res, next) => {
  console.error('Error:', err);
  res.status(err.status || 500).json({
    message: err.message || 'Internal server error',
    error: process.env.NODE_ENV === 'development' ? err : {}
  });
});

const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
  console.log('Available routes:');
  console.log('- POST /api/auth/google/callback');
  console.log('- POST /api/auth/github/callback');
  console.log('- POST /api/register');
  console.log('- POST /api/login');
  console.log('- GET /api/verify/:token');
  console.log('- GET /api/users/profile (protected)');
  console.log('- PUT /api/users/profile (protected)');
  console.log('- DELETE /api/users/profile (protected)');
  console.log('- GET /api/activities (protected)');
  console.log('- POST /api/activities (protected)');
  console.log('- GET /api/activities/stats (protected)');
  console.log('- DELETE /api/activities/:id (protected)');
  console.log('- POST /api/eco-scores/calculate (protected)');
  console.log('- GET /api/eco-scores/history (protected)');
  console.log('- GET /api/eco-scores/current (protected)');
  console.log('- PUT /api/eco-scores/goals (protected)');
});