const axios = require('axios');

// Get environment variables
const CARBON_FOOTPRINT_API_KEY = process.env.CARBON_FOOTPRINT_API_KEY || '';
const CARBON_FOOTPRINT_BASE_URL = 'https://api.carbonfootprint.com/v1';

// Rate limiting configuration
const RATE_LIMIT = {
  windowMs: 60 * 1000, // 1 minute
  maxRequests: 60, // 60 requests per minute
  message: 'Too many requests, please try again later.'
};

// Request tracking for rate limiting
const requestTracker = new Map();

// Custom error class
class CarbonFootprintServiceError extends Error {
  constructor(message, code, statusCode = 500, retryable = true) {
    super(message);
    this.name = 'CarbonFootprintServiceError';
    this.code = code;
    this.statusCode = statusCode;
    this.retryable = retryable;
  }
}

class CarbonFootprintService {
  checkApiKey() {
    if (!CARBON_FOOTPRINT_API_KEY) {
      throw new CarbonFootprintServiceError(
        'Carbon Footprint API key is not configured. Please add CARBON_FOOTPRINT_API_KEY to your .env file.',
        'API_NOT_CONFIGURED',
        500,
        false
      );
    }
  }

  async checkRateLimit(userId) {
    const now = Date.now();
    const userRequests = requestTracker.get(userId) || [];
    const recentRequests = userRequests.filter(time => now - time < RATE_LIMIT.windowMs);
    
    if (recentRequests.length >= RATE_LIMIT.maxRequests) {
      return false;
    }
    
    recentRequests.push(now);
    requestTracker.set(userId, recentRequests);
    return true;
  }

  async calculateCarbonFootprint(request, userId) {
    this.checkApiKey();
    
    // Check rate limit
    if (!(await this.checkRateLimit(userId))) {
      throw new CarbonFootprintServiceError(
        RATE_LIMIT.message,
        'RATE_LIMIT_EXCEEDED',
        429,
        true
      );
    }

    try {
      const url = `${CARBON_FOOTPRINT_BASE_URL}/calculate`;
      const headers = {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${CARBON_FOOTPRINT_API_KEY}`
      };
      
      const response = await axios.post(url, request, { headers });

      const data = response.data;
      
      // Generate recommendations based on the activity and carbon footprint
      const recommendations = this.generateRecommendations(request.activity, data.carbonKg);
      
      return {
        carbonKg: data.carbonKg,
        carbonLb: data.carbonLb,
        carbonMt: data.carbonMt,
        activity: request.activity,
        value: request.value,
        unit: request.unit,
        country: request.country,
        region: request.region,
        timestamp: Date.now(),
        recommendations: recommendations
      };
    } catch (error) {
      if (error.response) {
        throw new CarbonFootprintServiceError(
          `Carbon Footprint API error: ${error.response.statusText}`,
          'API_ERROR',
          error.response.status,
          error.response.status >= 500
        );
      }
      throw new CarbonFootprintServiceError(
        'Request failed',
        'NETWORK_ERROR',
        500,
        true
      );
    }
  }

  generateRecommendations(activity, carbonKg) {
    const recommendations = [];
    
    // Activity-specific recommendations
    if (activity.toLowerCase().includes('drive') || activity.toLowerCase().includes('car')) {
      if (carbonKg > 5) {
        recommendations.push('Consider carpooling or using public transportation to reduce your carbon footprint.');
        recommendations.push('Try walking or cycling for short trips.');
      }
      recommendations.push('Maintain your vehicle properly to improve fuel efficiency.');
    }
    
    if (activity.toLowerCase().includes('flight') || activity.toLowerCase().includes('plane')) {
      if (carbonKg > 100) {
        recommendations.push('Consider taking a train or bus for shorter distances.');
        recommendations.push('Look into carbon offset programs for unavoidable flights.');
      }
      recommendations.push('Choose direct flights when possible to reduce emissions.');
    }
    
    if (activity.toLowerCase().includes('electricity') || activity.toLowerCase().includes('energy')) {
      recommendations.push('Switch to renewable energy sources if available.');
      recommendations.push('Use energy-efficient appliances and LED lighting.');
      recommendations.push('Turn off lights and electronics when not in use.');
    }
    
    if (activity.toLowerCase().includes('food') || activity.toLowerCase().includes('diet')) {
      recommendations.push('Consider reducing meat consumption, especially beef.');
      recommendations.push('Buy local and seasonal produce when possible.');
      recommendations.push('Reduce food waste by planning meals and storing food properly.');
    }
    
    // General recommendations based on carbon footprint
    if (carbonKg > 10) {
      recommendations.push('This activity has a high carbon footprint. Consider alternatives or ways to reduce impact.');
    } else if (carbonKg < 1) {
      recommendations.push('Great choice! This activity has a low carbon footprint.');
    }
    
    return recommendations;
  }
}

module.exports = { 
  CarbonFootprintServiceError,
  carbonFootprintService: new CarbonFootprintService()
}; 