const ActivityLog = require('../models/ActivityLog');
const UserProfile = require('../models/UserProfile');
const { carbonFootprintService } = require('../services/carbonFootprintService');

// Get all activities for a user
const getUserActivities = async (req, res) => {
  try {
    const { page = 1, limit = 10, activityType, startDate, endDate } = req.query;
    const userId = req.user.id;

    const query = { userId };
    
    if (activityType) {
      query.activityType = activityType;
    }
    
    if (startDate || endDate) {
      query.timestamp = {};
      if (startDate) query.timestamp.$gte = new Date(startDate);
      if (endDate) query.timestamp.$lte = new Date(endDate);
    }

    const activities = await ActivityLog.find(query)
      .sort({ timestamp: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit)
      .exec();

    const total = await ActivityLog.countDocuments(query);

    res.json({
      activities,
      totalPages: Math.ceil(total / limit),
      currentPage: page,
      total
    });
  } catch (error) {
    console.error('Error fetching activities:', error);
    res.status(500).json({ message: 'Error fetching activities' });
  }
};

// Add a new activity
const addActivity = async (req, res) => {
  try {
    const userId = req.user.id;
    const { activityType, value, unit, description, location, metadata } = req.body;

    // Calculate carbon footprint
    const carbonData = await carbonFootprintService.calculateCarbonFootprint({
      activity: activityType,
      value: parseFloat(value),
      unit: unit,
      country: location?.country,
      region: location?.region
    }, userId);

    const activity = new ActivityLog({
      userId,
      activityType,
      value: parseFloat(value),
      unit,
      carbonFootprint: {
        carbonKg: carbonData.carbonKg,
        carbonLb: carbonData.carbonLb,
        carbonMt: carbonData.carbonMt
      },
      description,
      location,
      metadata
    });

    await activity.save();

    // Update user profile stats
    await updateUserStats(userId, carbonData.carbonKg);

    res.status(201).json({
      message: 'Activity logged successfully',
      activity,
      recommendations: carbonData.recommendations
    });
  } catch (error) {
    console.error('Error adding activity:', error);
    res.status(500).json({ message: 'Error adding activity' });
  }
};

// Get activity statistics
const getActivityStats = async (req, res) => {
  try {
    const userId = req.user.id;
    const { period = 'week' } = req.query;

    let startDate;
    const now = new Date();
    
    switch (period) {
      case 'day':
        startDate = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        break;
      case 'week':
        startDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
        break;
      case 'month':
        startDate = new Date(now.getFullYear(), now.getMonth(), 1);
        break;
      case 'year':
        startDate = new Date(now.getFullYear(), 0, 1);
        break;
      default:
        startDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    }

    const stats = await ActivityLog.aggregate([
      {
        $match: {
          userId: userId,
          timestamp: { $gte: startDate }
        }
      },
      {
        $group: {
          _id: '$activityType',
          count: { $sum: 1 },
          totalCarbon: { $sum: '$carbonFootprint.carbonKg' },
          averageCarbon: { $avg: '$carbonFootprint.carbonKg' }
        }
      }
    ]);

    const totalCarbon = stats.reduce((sum, stat) => sum + stat.totalCarbon, 0);
    const totalActivities = stats.reduce((sum, stat) => sum + stat.count, 0);

    res.json({
      period,
      totalCarbon,
      totalActivities,
      byCategory: stats,
      startDate,
      endDate: now
    });
  } catch (error) {
    console.error('Error fetching activity stats:', error);
    res.status(500).json({ message: 'Error fetching activity statistics' });
  }
};

// Update user stats helper function
const updateUserStats = async (userId, carbonReduced) => {
  try {
    await UserProfile.findOneAndUpdate(
      { userId },
      {
        $inc: {
          'stats.totalCarbonReduced': carbonReduced,
          'stats.totalActivities': 1
        }
      },
      { upsert: true }
    );
  } catch (error) {
    console.error('Error updating user stats:', error);
  }
};

// Delete an activity
const deleteActivity = async (req, res) => {
  try {
    const { id } = req.params;
    const userId = req.user.id;

    const activity = await ActivityLog.findOneAndDelete({ _id: id, userId });
    
    if (!activity) {
      return res.status(404).json({ message: 'Activity not found' });
    }

    res.json({ message: 'Activity deleted successfully' });
  } catch (error) {
    console.error('Error deleting activity:', error);
    res.status(500).json({ message: 'Error deleting activity' });
  }
};

module.exports = {
  getUserActivities,
  addActivity,
  getActivityStats,
  deleteActivity
}; 