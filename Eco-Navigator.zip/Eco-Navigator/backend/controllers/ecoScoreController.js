const EcoScore = require('../models/EcoScore');
const ActivityLog = require('../models/ActivityLog');
const UserProfile = require('../models/UserProfile');

// Calculate and save eco score
const calculateEcoScore = async (req, res) => {
  try {
    const userId = req.user.id;
    const { categoryScores, goals } = req.body;

    // Calculate overall score
    const overallScore = calculateOverallScore(categoryScores);

    // Calculate carbon footprint from recent activities
    const carbonFootprint = await calculateCarbonFootprint(userId);

    // Generate recommendations
    const recommendations = generateRecommendations(categoryScores, overallScore);

    const ecoScore = new EcoScore({
      userId,
      overallScore,
      categoryScores,
      carbonFootprint,
      recommendations,
      goals: goals || []
    });

    await ecoScore.save();

    // Update user profile
    await UserProfile.findOneAndUpdate(
      { userId },
      {
        $set: {
          'goals.ecoScore.current': overallScore
        }
      },
      { upsert: true }
    );

    res.status(201).json({
      message: 'Eco score calculated successfully',
      ecoScore
    });
  } catch (error) {
    console.error('Error calculating eco score:', error);
    res.status(500).json({ message: 'Error calculating eco score' });
  }
};

// Get user's eco score history
const getEcoScoreHistory = async (req, res) => {
  try {
    const userId = req.user.id;
    const { limit = 10 } = req.query;

    const scores = await EcoScore.find({ userId })
      .sort({ timestamp: -1 })
      .limit(parseInt(limit))
      .select('overallScore categoryScores carbonFootprint timestamp');

    res.json({ scores });
  } catch (error) {
    console.error('Error fetching eco score history:', error);
    res.status(500).json({ message: 'Error fetching eco score history' });
  }
};

// Get current eco score
const getCurrentEcoScore = async (req, res) => {
  try {
    const userId = req.user.id;

    const currentScore = await EcoScore.findOne({ userId })
      .sort({ timestamp: -1 })
      .populate('recommendations');

    if (!currentScore) {
      return res.status(404).json({ message: 'No eco score found' });
    }

    res.json({ ecoScore: currentScore });
  } catch (error) {
    console.error('Error fetching current eco score:', error);
    res.status(500).json({ message: 'Error fetching current eco score' });
  }
};

// Update eco score goals
const updateEcoScoreGoals = async (req, res) => {
  try {
    const userId = req.user.id;
    const { goals } = req.body;

    const ecoScore = await EcoScore.findOneAndUpdate(
      { userId },
      { $set: { goals } },
      { new: true, upsert: true }
    );

    res.json({
      message: 'Goals updated successfully',
      ecoScore
    });
  } catch (error) {
    console.error('Error updating eco score goals:', error);
    res.status(500).json({ message: 'Error updating goals' });
  }
};

// Helper function to calculate overall score
const calculateOverallScore = (categoryScores) => {
  const weights = {
    transportation: 0.25,
    diet: 0.25,
    energy: 0.25,
    waste: 0.15,
    water: 0.10
  };

  let totalScore = 0;
  let totalWeight = 0;

  Object.keys(categoryScores).forEach(category => {
    if (categoryScores[category]?.score && weights[category]) {
      totalScore += categoryScores[category].score * weights[category];
      totalWeight += weights[category];
    }
  });

  return totalWeight > 0 ? Math.round(totalScore / totalWeight) : 0;
};

// Helper function to calculate carbon footprint from activities
const calculateCarbonFootprint = async (userId) => {
  try {
    const now = new Date();
    const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    const monthAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
    const yearAgo = new Date(now.getTime() - 365 * 24 * 60 * 60 * 1000);

    const [weekly, monthly, yearly] = await Promise.all([
      ActivityLog.aggregate([
        {
          $match: {
            userId: userId,
            timestamp: { $gte: weekAgo }
          }
        },
        {
          $group: {
            _id: null,
            total: { $sum: '$carbonFootprint.carbonKg' }
          }
        }
      ]),
      ActivityLog.aggregate([
        {
          $match: {
            userId: userId,
            timestamp: { $gte: monthAgo }
          }
        },
        {
          $group: {
            _id: null,
            total: { $sum: '$carbonFootprint.carbonKg' }
          }
        }
      ]),
      ActivityLog.aggregate([
        {
          $match: {
            userId: userId,
            timestamp: { $gte: yearAgo }
          }
        },
        {
          $group: {
            _id: null,
            total: { $sum: '$carbonFootprint.carbonKg' }
          }
        }
      ])
    ]);

    return {
      daily: weekly[0]?.total / 7 || 0,
      weekly: weekly[0]?.total || 0,
      monthly: monthly[0]?.total || 0,
      yearly: yearly[0]?.total || 0
    };
  } catch (error) {
    console.error('Error calculating carbon footprint:', error);
    return { daily: 0, weekly: 0, monthly: 0, yearly: 0 };
  }
};

// Helper function to generate recommendations
const generateRecommendations = (categoryScores, overallScore) => {
  const recommendations = [];

  // Transportation recommendations
  if (categoryScores.transportation?.score < 70) {
    recommendations.push({
      category: 'Transportation',
      tip: 'Consider using public transportation or carpooling to reduce your carbon footprint',
      impact: 'High',
      effort: 'Medium'
    });
  }

  // Diet recommendations
  if (categoryScores.diet?.score < 70) {
    recommendations.push({
      category: 'Diet',
      tip: 'Try reducing meat consumption and opt for local, seasonal produce',
      impact: 'Medium',
      effort: 'Low'
    });
  }

  // Energy recommendations
  if (categoryScores.energy?.score < 70) {
    recommendations.push({
      category: 'Energy',
      tip: 'Switch to energy-efficient appliances and consider renewable energy sources',
      impact: 'Medium',
      effort: 'Medium'
    });
  }

  // Waste recommendations
  if (categoryScores.waste?.score < 70) {
    recommendations.push({
      category: 'Waste',
      tip: 'Start composting and reduce single-use plastics in your daily routine',
      impact: 'High',
      effort: 'Low'
    });
  }

  // General recommendations based on overall score
  if (overallScore < 50) {
    recommendations.push({
      category: 'General',
      tip: 'Focus on small daily changes to improve your environmental impact',
      impact: 'Medium',
      effort: 'Low'
    });
  }

  return recommendations;
};

module.exports = {
  calculateEcoScore,
  getEcoScoreHistory,
  getCurrentEcoScore,
  updateEcoScoreGoals
}; 