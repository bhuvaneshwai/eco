// backend/config/db.js
const mongoose = require('mongoose');

const connectDB = async () => {
  const maxRetries = 5;
  let retries = 0;

  while (retries < maxRetries) {
    try {
      console.log(`Attempting to connect to MongoDB... (attempt ${retries + 1}/${maxRetries})`);
      
      if (!process.env.MONGO_URI) {
        throw new Error('MONGO_URI environment variable is not set. Please check your .env file.');
      }

      const conn = await mongoose.connect(process.env.MONGO_URI, {
        serverSelectionTimeoutMS: 5000, // 5 second timeout
        socketTimeoutMS: 45000,
      });
      
      console.log(`✅ MongoDB Connected: ${conn.connection.host}`);
      return;
    } catch (error) {
      retries++;
      console.error(`❌ MongoDB connection attempt ${retries} failed: ${error.message}`);
      
      if (retries >= maxRetries) {
        console.error('❌ Failed to connect to MongoDB after multiple attempts.');
        console.error('💡 Please make sure MongoDB is running. You can:');
        console.error('   1. Start MongoDB service: net start MongoDB (as Administrator)');
        console.error('   2. Or start MongoDB manually: mongod');
        console.error('   3. Or use MongoDB Compass to start the service');
        process.exit(1);
      }
      
      console.log(`⏳ Retrying in 3 seconds...`);
      await new Promise(resolve => setTimeout(resolve, 3000));
    }
  }
};

module.exports = connectDB;