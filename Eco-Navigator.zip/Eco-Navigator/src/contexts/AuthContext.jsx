import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from "sonner";
import * as api from '@/services/apiService';
import { logger } from '@/utils/logger';

const AuthContext = createContext(undefined);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  const loadUserFromToken = useCallback(async () => {
    const token = localStorage.getItem('token');
    if (token) {
      try {
        const profile = await api.getProfile();
        setUser(profile);
      } catch (error) {
        logger.error('Failed to fetch profile with token:', error);
        localStorage.removeItem('token');
        setUser(null);
      }
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    loadUserFromToken();
  }, [loadUserFromToken]);

  const signUp = async (userData) => {
    try {
      const data = await api.register(userData);
      setUser(data.user);
      navigate('/dashboard');
      toast.success('Account created successfully!');
      return data;
    } catch (error) {
      logger.error('Sign up error in context:', error);
      toast.error(error.response?.data?.message || 'Registration failed.');
      throw error;
    }
  };

  const login = async (credentials) => {
    try {
      const data = await api.login(credentials);
      setUser(data.user);
      navigate('/dashboard');
      toast.success('Logged in successfully!');
      return data;
    } catch (error) {
      logger.error('Login error in context:', error);
      toast.error(error.response?.data?.message || 'Login failed.');
      throw error;
    }
  };
  
  const socialLogin = async (provider, code) => {
    try {
      const response = await api.socialLogin(provider, code);
      setUser(response.user);
      localStorage.setItem('token', response.token);
      navigate('/dashboard');
      toast.success(`Logged in with ${provider} successfully!`);
      return response;
    } catch (error) {
       logger.error('Social login error in context:', error);
       toast.error(error.response?.data?.message || `Social login with ${provider} failed.`);
       throw error;
    }
  };

  const logout = () => {
    api.logout();
    setUser(null);
    navigate('/login');
    toast.info("You have been logged out.");
  };
  
  const updateProfile = async (profileData) => {
    try {
      const updatedUser = await api.updateProfile(profileData);
      setUser(updatedUser);
      toast.success('Profile updated successfully!');
      return updatedUser;
    } catch (error) {
      logger.error('Profile update error in context:', error);
      toast.error(error.response?.data?.message || 'Failed to update profile.');
      throw error;
    }
  };

  return (
    <AuthContext.Provider value={{
      user,
      setUser,
      loading,
      signUp,
      login,
      socialLogin,
      logout,
      updateProfile,
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}; 