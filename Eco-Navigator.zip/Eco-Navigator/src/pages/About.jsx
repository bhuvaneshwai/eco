const About = () => {
  return (
    <div className="min-h-screen pt-16">
      <div className="container mx-auto px-4 py-12">
        <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-6">
          About Eco-Navigator
        </h1>
        <div className="prose dark:prose-invert max-w-none">
          <p className="text-lg text-gray-600 dark:text-gray-300 mb-8">
            Eco-Navigator is dedicated to helping you achieve your health and wellness goals through sustainable practices and personalized guidance.
          </p>
          <p className="text-lg text-gray-600 dark:text-gray-300 mb-6">
            Our mission is to empower individuals to make informed decisions about their health and well-being, while promoting sustainable and eco-friendly practices.
          </p>
          <p className="text-lg text-gray-600 dark:text-gray-300">
            We believe that true wellness comes from a balanced approach to physical, mental, and environmental health.
          </p>
        </div>
      </div>
    </div>
  );
};

export default About; 