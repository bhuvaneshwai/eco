import { Link } from 'react-router-dom';
import SignUpForm from '@/components/auth/SignUpForm';
import SocialLoginButtons from '@/components/auth/SocialLoginButtons';
import { useTheme } from '@/components/theme-provider';

const Signup = () => {
  const { theme } = useTheme();

  return (
    <div className={`min-h-screen bg-background p-6 ${theme === 'dark' ? 'dark' : ''}`}>
      <div className="max-w-md mx-auto space-y-6">
        <div className="text-center">
          <h1 className="text-3xl font-bold">Create an Account</h1>
          <p className="text-muted-foreground mt-2">Join Eco-Navigator to track your eco-friendly habits</p>
        </div>

        <SignUpForm />

        <div className="relative">
          <div className="absolute inset-0 flex items-center">
            <span className="w-full border-t" />
          </div>
          <div className="relative flex justify-center text-xs uppercase">
            <span className="bg-background px-2 text-muted-foreground">Or continue with</span>
          </div>
        </div>

        <SocialLoginButtons />
        
        <div className="text-center text-sm">
          Already have an account?{' '}
          <Link to="/login" className="font-medium text-primary hover:underline">
            Log in
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Signup; 