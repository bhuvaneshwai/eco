import { LRUCache } from 'lru-cache';
import { logger } from '../utils/logger';

// Get environment variables
const OPENWEATHER_API_KEY = import.meta.env.VITE_OPENWEATHER_API_KEY || '';
const OPENWEATHER_BASE_URL = 'https://api.openweathermap.org/data/2.5';

// Cache configuration
const CACHE_CONFIG = {
  max: 100,
  ttl: 1000 * 60 * 30, // 30 minutes
  updateAgeOnGet: true
};

// Rate limiting configuration
const RATE_LIMIT = {
  windowMs: 60 * 1000, // 1 minute
  maxRequests: 60, // 60 requests per minute
  message: 'Too many requests, please try again later.'
};

// Retry Configuration
const RETRY_CONFIG = {
  maxRetries: 3,
  initialDelay: 1000, // 1 second
  maxDelay: 5000, // 5 seconds
  backoffFactor: 2
};

// Create cache instance
const weatherCache = new LRUCache(CACHE_CONFIG);
const airQualityCache = new LRUCache(CACHE_CONFIG);

// Request tracking for rate limiting
const requestTracker = new Map();

// Custom error class
export class OpenWeatherServiceError extends Error {
  constructor(message, code, statusCode = 500, retryable = true) {
    super(message);
    this.name = 'OpenWeatherServiceError';
    this.code = code;
    this.statusCode = statusCode;
    this.retryable = retryable;
  }
}

class OpenWeatherService {
  constructor() {
    this.maxRetries = RETRY_CONFIG.maxRetries;
    this.initialDelay = RETRY_CONFIG.initialDelay;
    this.maxDelay = RETRY_CONFIG.maxDelay;
    this.backoffFactor = RETRY_CONFIG.backoffFactor;
  }

  checkApiKey() {
    if (!OPENWEATHER_API_KEY) {
      throw new OpenWeatherServiceError(
        'OpenWeather API key is not configured. Please add VITE_OPENWEATHER_API_KEY to your .env file.',
        'API_NOT_CONFIGURED',
        500,
        false
      );
    }
  }

  async checkRateLimit(userId) {
    const now = Date.now();
    const userRequests = requestTracker.get(userId) || [];
    const recentRequests = userRequests.filter(time => now - time < RATE_LIMIT.windowMs);
    
    if (recentRequests.length >= RATE_LIMIT.maxRequests) {
      return false;
    }
    
    recentRequests.push(now);
    requestTracker.set(userId, recentRequests);
    return true;
  }

  async delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  calculateBackoff(attempt) {
    const delay = Math.min(
      this.initialDelay * Math.pow(this.backoffFactor, attempt - 1),
      this.maxDelay
    );
    return delay + Math.random() * 1000; // Add jitter
  }

  async makeRequestWithRetry(requestFn, cacheKey, userId, cache) {
    // Check rate limit
    if (!(await this.checkRateLimit(userId))) {
      throw new OpenWeatherServiceError(
        RATE_LIMIT.message,
        'RATE_LIMIT_EXCEEDED',
        429,
        true
      );
    }

    // Check cache
    const cachedResponse = cache.get(cacheKey);
    if (cachedResponse) {
      logger.info(`Cache hit for key: ${cacheKey}`);
      return cachedResponse;
    }

    // Make request with retry logic
    let lastError = null;
    for (let attempt = 1; attempt <= this.maxRetries; attempt++) {
      try {
        const response = await requestFn();
        cache.set(cacheKey, response);
        return response;
      } catch (error) {
        lastError = error instanceof Error ? error : new Error(String(error));
        logger.warn(`Attempt ${attempt} failed: ${lastError.message}`);
        
        if (attempt < this.maxRetries) {
          const backoffDelay = this.calculateBackoff(attempt);
          await this.delay(backoffDelay);
        }
      }
    }

    logger.error(`All retry attempts failed: ${lastError?.message}`);
    throw new OpenWeatherServiceError(
      'Request failed after multiple attempts',
      'MAX_RETRIES_EXCEEDED',
      500,
      false
    );
  }

  async getWeather(request, userId) {
    this.checkApiKey();
    const units = request.units || 'metric';
    const cacheKey = `weather-${request.lat}-${request.lon}-${units}`;
    
    return this.makeRequestWithRetry(
      async () => {
        const url = `${OPENWEATHER_BASE_URL}/weather?lat=${request.lat}&lon=${request.lon}&units=${units}&appid=${OPENWEATHER_API_KEY}`;
        const response = await fetch(url);

        if (!response.ok) {
          throw new OpenWeatherServiceError(
            `OpenWeather API error: ${response.statusText}`,
            'API_ERROR',
            response.status,
            response.status >= 500
          );
        }

        const data = await response.json();
        return this.generateWeatherResponse(data, units);
      },
      cacheKey,
      userId,
      weatherCache
    );
  }

  async getAirQuality(request, userId) {
    this.checkApiKey();
    const cacheKey = `airquality-${request.lat}-${request.lon}`;
    
    return this.makeRequestWithRetry(
      async () => {
        const url = `${OPENWEATHER_BASE_URL}/air_pollution?lat=${request.lat}&lon=${request.lon}&appid=${OPENWEATHER_API_KEY}`;
        const response = await fetch(url);

        if (!response.ok) {
          throw new OpenWeatherServiceError(
            `OpenWeather API error: ${response.statusText}`,
            'API_ERROR',
            response.status,
            response.status >= 500
          );
        }

        const data = await response.json();
        return this.generateAirQualityResponse(data);
      },
      cacheKey,
      userId,
      airQualityCache
    );
  }

  generateWeatherResponse(data, units) {
    const tempUnit = units === 'metric' ? '°C' : '°F';
    const speedUnit = units === 'metric' ? 'm/s' : 'mph';
    
    return {
      temperature: data.main.temp,
      feelsLike: data.main.feels_like,
      humidity: data.main.humidity,
      pressure: data.main.pressure,
      windSpeed: data.wind.speed,
      windDirection: data.wind.deg,
      description: data.weather[0].description,
      icon: data.weather[0].icon,
      timestamp: Date.now(),
      recommendations: this.generateWeatherRecommendations(data, units)
    };
  }

  generateAirQualityResponse(data) {
    const aqi = data.list[0].main.aqi;
    
    return {
      aqi: aqi,
      pm25: data.list[0].components.pm2_5,
      pm10: data.list[0].components.pm10,
      o3: data.list[0].components.o3,
      no2: data.list[0].components.no2,
      so2: data.list[0].components.so2,
      co: data.list[0].components.co,
      timestamp: Date.now(),
      recommendations: this.generateAirQualityRecommendations(data)
    };
  }

  generateWeatherRecommendations(data, units) {
    const recommendations = [];
    const temp = data.main.temp;
    const tempUnit = units === 'metric' ? '°C' : '°F';
    
    if (temp < 10) {
      recommendations.push('Bundle up! It\'s cold outside.');
      recommendations.push('Consider indoor activities to stay warm.');
    } else if (temp > 30) {
      recommendations.push('Stay hydrated and avoid prolonged sun exposure.');
      recommendations.push('Consider early morning or evening outdoor activities.');
    }
    
    if (data.main.humidity > 80) {
      recommendations.push('High humidity - stay hydrated and take breaks.');
    }
    
    if (data.wind.speed > 10) {
      recommendations.push('Windy conditions - secure loose items and dress appropriately.');
    }
    
    return recommendations;
  }

  generateAirQualityRecommendations(data) {
    const recommendations = [];
    const aqi = data.list[0].main.aqi;
    
    if (aqi >= 4) {
      recommendations.push('Poor air quality - limit outdoor activities.');
      recommendations.push('Consider indoor exercise alternatives.');
    } else if (aqi >= 3) {
      recommendations.push('Moderate air quality - sensitive groups should limit outdoor activities.');
    } else {
      recommendations.push('Good air quality - great time for outdoor activities!');
    }
    
    return recommendations;
  }
}

export const openWeatherService = new OpenWeatherService();
export default openWeatherService; 