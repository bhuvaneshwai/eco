import { LRUCache } from 'lru-cache';
import { logger } from '../utils/logger.js';

// Get environment variables
const CARBON_FOOTPRINT_API_KEY = import.meta.env.VITE_CARBON_FOOTPRINT_API_KEY || '';
const CARBON_FOOTPRINT_BASE_URL = 'https://api.carbonfootprint.com/v1';

// Cache configuration
const CACHE_CONFIG = {
  max: 100,
  ttl: 1000 * 60 * 60, // 1 hour
  updateAgeOnGet: true
};

// Rate limiting configuration
const RATE_LIMIT = {
  windowMs: 60 * 1000, // 1 minute
  maxRequests: 60, // 60 requests per minute
  message: 'Too many requests, please try again later.'
};

// Retry Configuration
const RETRY_CONFIG = {
  maxRetries: 3,
  initialDelay: 1000, // 1 second
  maxDelay: 5000, // 5 seconds
  backoffFactor: 2
};

// Create cache instance
const carbonFootprintCache = new LRUCache(CACHE_CONFIG);

// Request tracking for rate limiting
const requestTracker = new Map();

// Custom error class
export class CarbonFootprintServiceError extends Error {
  constructor(message, code, statusCode = 500, retryable = true) {
    super(message);
    this.name = 'CarbonFootprintServiceError';
    this.code = code;
    this.statusCode = statusCode;
    this.retryable = retryable;
  }
}

class CarbonFootprintService {
  constructor() {
    this.maxRetries = RETRY_CONFIG.maxRetries;
    this.initialDelay = RETRY_CONFIG.initialDelay;
    this.maxDelay = RETRY_CONFIG.maxDelay;
    this.backoffFactor = RETRY_CONFIG.backoffFactor;
  }

  checkApiKey() {
    if (!CARBON_FOOTPRINT_API_KEY) {
      throw new CarbonFootprintServiceError(
        'Carbon Footprint API key is not configured. Please add VITE_CARBON_FOOTPRINT_API_KEY to your .env file.',
        'API_NOT_CONFIGURED',
        500,
        false
      );
    }
  }

  async checkRateLimit(userId) {
    const now = Date.now();
    const userRequests = requestTracker.get(userId) || [];
    const recentRequests = userRequests.filter(time => now - time < RATE_LIMIT.windowMs);
    
    if (recentRequests.length >= RATE_LIMIT.maxRequests) {
      return false;
    }
    
    recentRequests.push(now);
    requestTracker.set(userId, recentRequests);
    return true;
  }

  async delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  calculateBackoff(attempt) {
    const delay = Math.min(
      this.initialDelay * Math.pow(this.backoffFactor, attempt - 1),
      this.maxDelay
    );
    return delay + Math.random() * 1000; // Add jitter
  }

  async makeRequestWithRetry(requestFn, cacheKey, userId) {
    // Check rate limit
    if (!(await this.checkRateLimit(userId))) {
      throw new CarbonFootprintServiceError(
        RATE_LIMIT.message,
        'RATE_LIMIT_EXCEEDED',
        429,
        true
      );
    }

    // Check cache
    const cachedResponse = carbonFootprintCache.get(cacheKey);
    if (cachedResponse) {
      logger.info(`Cache hit for key: ${cacheKey}`);
      return cachedResponse;
    }

    // Make request with retry logic
    let lastError = null;
    for (let attempt = 1; attempt <= this.maxRetries; attempt++) {
      try {
        const response = await requestFn();
        carbonFootprintCache.set(cacheKey, response);
        return response;
      } catch (error) {
        lastError = error instanceof Error ? error : new Error(String(error));
        logger.warn(`Attempt ${attempt} failed: ${lastError.message}`);
        
        if (attempt < this.maxRetries) {
          const backoffDelay = this.calculateBackoff(attempt);
          await this.delay(backoffDelay);
        }
      }
    }

    logger.error(`All retry attempts failed: ${lastError?.message}`);
    throw new CarbonFootprintServiceError(
      'Request failed after multiple attempts',
      'MAX_RETRIES_EXCEEDED',
      500,
      false
    );
  }

  async calculateCarbonFootprint(request, userId) {
    this.checkApiKey();
    const cacheKey = `carbon-${request.activity}-${request.value}-${request.unit}-${request.country || 'global'}-${request.region || 'global'}`;
    
    return this.makeRequestWithRetry(
      async () => {
        const url = `${CARBON_FOOTPRINT_BASE_URL}/calculate`;
        const headers = {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${CARBON_FOOTPRINT_API_KEY}`
        };
        
        const response = await fetch(url, {
          method: 'POST',
          headers,
          body: JSON.stringify(request)
        });

        if (!response.ok) {
          throw new CarbonFootprintServiceError(
            `Carbon Footprint API error: ${response.statusText}`,
            'API_ERROR',
            response.status,
            response.status >= 500
          );
        }

        const data = await response.json();
        
        // Generate recommendations based on the activity and carbon footprint
        const recommendations = this.generateRecommendations(request.activity, data.carbonKg);
        
        return {
          carbonKg: data.carbonKg,
          carbonLb: data.carbonLb,
          carbonMt: data.carbonMt,
          activity: request.activity,
          value: request.value,
          unit: request.unit,
          country: request.country,
          region: request.region,
          timestamp: Date.now(),
          recommendations: recommendations
        };
      },
      cacheKey,
      userId
    );
  }

  generateRecommendations(activity, carbonKg) {
    const recommendations = [];
    
    // Activity-specific recommendations
    if (activity.toLowerCase().includes('drive') || activity.toLowerCase().includes('car')) {
      if (carbonKg > 5) {
        recommendations.push('Consider carpooling or using public transportation to reduce your carbon footprint.');
        recommendations.push('Try walking or cycling for short trips.');
      }
      recommendations.push('Maintain your vehicle properly to improve fuel efficiency.');
    }
    
    if (activity.toLowerCase().includes('flight') || activity.toLowerCase().includes('plane')) {
      if (carbonKg > 100) {
        recommendations.push('Consider taking a train or bus for shorter distances.');
        recommendations.push('Look into carbon offset programs for unavoidable flights.');
      }
      recommendations.push('Choose direct flights when possible to reduce emissions.');
    }
    
    if (activity.toLowerCase().includes('electricity') || activity.toLowerCase().includes('energy')) {
      recommendations.push('Switch to renewable energy sources if available.');
      recommendations.push('Use energy-efficient appliances and LED lighting.');
      recommendations.push('Turn off lights and electronics when not in use.');
    }
    
    if (activity.toLowerCase().includes('food') || activity.toLowerCase().includes('diet')) {
      recommendations.push('Consider reducing meat consumption, especially beef.');
      recommendations.push('Buy local and seasonal produce when possible.');
      recommendations.push('Reduce food waste by planning meals and storing food properly.');
    }
    
    // General recommendations based on carbon footprint
    if (carbonKg > 10) {
      recommendations.push('This activity has a high carbon footprint. Consider alternatives or ways to reduce impact.');
    } else if (carbonKg < 1) {
      recommendations.push('Great choice! This activity has a low carbon footprint.');
    }
    
    return recommendations;
  }
}

export const carbonFootprintService = new CarbonFootprintService();
export default carbonFootprintService; 