import axios from 'axios';
import { logger } from '@/utils/logger.js';

const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:3000';

const api = axios.create({
  baseURL: `${API_BASE_URL}/api`,
  headers: {
    'Content-Type': 'application/json',
  },
  withCredentials: true // Send cookies with requests
});

// Add a request interceptor to include the auth token
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers['Authorization'] = `Bearer ${token}`;
    }
    logger.info(`API Request: ${config.method?.toUpperCase()} ${config.url}`);
    return config;
  },
  (error) => {
    logger.error('API Request Error:', error);
    return Promise.reject(error);
  }
);

// Add a response interceptor for logging
api.interceptors.response.use(
  (response) => {
    logger.info(`API Response: ${response.status} ${response.config.url}`);
    return response;
  },
  (error) => {
    logger.error('API Response Error:', error.response?.data?.message || error.message);
    return Promise.reject(error);
  }
);

// User/Auth Service Functions
export const register = async (userData) => {
  const response = await api.post('/register', userData);
  if (response.data.token) {
    localStorage.setItem('token', response.data.token);
  }
  return response.data;
};

export const login = async (credentials) => {
  const response = await api.post('/login', credentials);
  if (response.data.token) {
    localStorage.setItem('token', response.data.token);
  }
  return response.data;
};

export const logout = () => {
  localStorage.removeItem('token');
};

export const getProfile = async () => {
  const response = await api.get('/users/profile');
  return response.data;
};

export const updateProfile = async (profileData) => {
  const response = await api.put('/users/profile', profileData);
  return response.data;
};

// Activity Log Service Functions
export const addActivity = async (activityData) => {
  const response = await api.post('/activities', activityData);
  return response.data;
};

export const getUserActivities = async (params) => {
  const response = await api.get('/activities', { params });
  return response.data;
};

export const getActivityStats = async (params) => {
  const response = await api.get('/activities/stats', { params });
  return response.data;
};

// Eco Score Service Functions
export const calculateEcoScore = async (scoreData) => {
  const response = await api.post('/eco-scores/calculate', scoreData);
  return response.data;
};

export const getCurrentEcoScore = async () => {
  const response = await api.get('/eco-scores/current');
  return response.data;
};

export const getEcoScoreHistory = async (params) => {
  const response = await api.get('/eco-scores/history', { params });
  return response.data;
};

// AI Service Functions
export const generateMealPlan = async (preferences) => {
  const response = await api.post('/ai/meal-plan', preferences);
  return response.data;
};

export const generateWorkoutPlan = async (fitnessLevel, goals) => {
  const response = await api.post('/ai/workout-plan', { fitnessLevel, goals });
  return response.data;
};

export const getSustainabilityTips = async () => {
  const response = await api.get('/ai/sustainability-tips');
  return response.data;
};

export default api; 