import { GoogleGenerativeAI } from '@google/generative-ai';
import { LRUCache } from 'lru-cache';
import { logger } from '../utils/logger.js';
import {
  validateWorkoutPlanRequest,
  validateActivityRecommendationRequest,
  validateMealPlanRequest,
  validateEcoScoreRequest
} from '../utils/validation.js';

// Get environment variables directly from import.meta.env
const GEMINI_API_KEY = import.meta.env.VITE_GEMINI_API_KEY || '';

// Add detailed logging
console.log('Environment variables:', {
  VITE_GEMINI_API_KEY: import.meta.env.VITE_GEMINI_API_KEY,
  VITE_GEMINI_API_KEY_LENGTH: import.meta.env.VITE_GEMINI_API_KEY?.length,
  ALL_ENV_KEYS: Object.keys(import.meta.env)
});

// Initialize the Gemini API
let genAI = null;

try {
  if (!GEMINI_API_KEY) {
    console.warn('Gemini API key is not configured. AI features will be disabled.');
  } else {
    // Initialize with the API key
    genAI = new GoogleGenerativeAI(GEMINI_API_KEY);
    
    // Log the API key length (not the actual key) for debugging
    logger.info(`Using Gemini API key of length: ${GEMINI_API_KEY.length}`);
  }
} catch (error) {
  console.error('Error initializing Gemini API:', error);
}

// Cache configuration
const CACHE_CONFIG = {
  max: 500,
  ttl: 1000 * 60 * 60, // 1 hour
  updateAgeOnGet: true
};

// Rate limiting configuration
const RATE_LIMIT = {
  windowMs: 60 * 1000, // 1 minute
  maxRequests: 60, // 60 requests per minute
  message: 'Too many requests, please try again later.'
};

// AI Model Configuration
const AI_CONFIG = {
  model: 'gemini-1.5-pro',
  temperature: 0.7,
  maxOutputTokens: 2048,
  topP: 0.8,
  topK: 40
};

// Retry Configuration
const RETRY_CONFIG = {
  maxRetries: 3,
  initialDelay: 1000, // 1 second
  maxDelay: 5000, // 5 seconds
  backoffFactor: 2
};

// Feature Flags
const FEATURES = {
  enableCaching: true,
  enableRateLimiting: true,
  enableRetries: true,
  enableLogging: true
};

// Create cache instances for different types of requests
const workoutPlanCache = new LRUCache(CACHE_CONFIG);
const activityRecommendationCache = new LRUCache(CACHE_CONFIG);
const ecoScoreCache = new LRUCache(CACHE_CONFIG);
const mealPlanCache = new LRUCache(CACHE_CONFIG);

// Request tracking for rate limiting
const requestTracker = new Map();

// Custom error class for Gemini service
export class GeminiServiceError extends Error {
  constructor(message, code, statusCode = 500, retryable = true, validationErrors) {
    super(message);
    this.name = 'GeminiServiceError';
    this.code = code;
    this.statusCode = statusCode;
    this.retryable = retryable;
    this.validationErrors = validationErrors;
  }
}

class GeminiService {
  constructor() {
    this.maxRetries = RETRY_CONFIG.maxRetries;
    this.initialDelay = RETRY_CONFIG.initialDelay;
    this.maxDelay = RETRY_CONFIG.maxDelay;
    this.backoffFactor = RETRY_CONFIG.backoffFactor;
    
    if (genAI) {
      this.model = genAI.getGenerativeModel(AI_CONFIG);
    }
  }

  checkAIAvailability() {
    if (!genAI || !this.model) {
      throw new GeminiServiceError(
        'AI service is not available. Please check your API key configuration.',
        'AI_UNAVAILABLE',
        503,
        false
      );
    }
  }

  async checkRateLimit(userId) {
    if (!FEATURES.enableRateLimiting) return true;
    
    const now = Date.now();
    const windowStart = now - RATE_LIMIT.windowMs;
    
    if (!requestTracker.has(userId)) {
      requestTracker.set(userId, []);
    }
    
    const userRequests = requestTracker.get(userId);
    const recentRequests = userRequests.filter(timestamp => timestamp > windowStart);
    
    if (recentRequests.length >= RATE_LIMIT.maxRequests) {
      throw new GeminiServiceError(
        RATE_LIMIT.message,
        'RATE_LIMIT_EXCEEDED',
        429,
        true
      );
    }
    
    recentRequests.push(now);
    requestTracker.set(userId, recentRequests);
    return true;
  }

  async delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  calculateBackoff(attempt) {
    const delay = this.initialDelay * Math.pow(this.backoffFactor, attempt - 1);
    return Math.min(delay, this.maxDelay);
  }

  async makeRequestWithRetry(requestFn, cacheKey, cache, userId) {
    // Check cache first
    if (FEATURES.enableCaching && cache.has(cacheKey)) {
      logger.info(`Cache hit for key: ${cacheKey}`);
      return cache.get(cacheKey);
    }

    // Check rate limit
    await this.checkRateLimit(userId);

    let lastError;
    
    for (let attempt = 1; attempt <= this.maxRetries; attempt++) {
      try {
        const result = await requestFn();
        
        // Cache the result
        if (FEATURES.enableCaching) {
          cache.set(cacheKey, result);
        }
        
        return result;
      } catch (error) {
        lastError = error;
        
        if (attempt === this.maxRetries || !error.retryable) {
          throw error;
        }
        
        const backoffDelay = this.calculateBackoff(attempt);
        logger.warn(`Request failed, retrying in ${backoffDelay}ms (attempt ${attempt}/${this.maxRetries})`);
        await this.delay(backoffDelay);
      }
    }
    
    throw lastError;
  }

  async generateContent(prompt) {
    this.checkAIAvailability();
    
    try {
      const result = await this.model.generateContent(prompt);
      const response = await result.response;
      return response.text();
    } catch (error) {
      logger.error('Error generating content:', error);
      
      if (error.message.includes('API key')) {
        throw new GeminiServiceError(
          'Invalid API key. Please check your configuration.',
          'INVALID_API_KEY',
          401,
          false
        );
      }
      
      if (error.message.includes('quota')) {
        throw new GeminiServiceError(
          'API quota exceeded. Please try again later.',
          'QUOTA_EXCEEDED',
          429,
          true
        );
      }
      
      throw new GeminiServiceError(
        'Failed to generate content. Please try again.',
        'GENERATION_FAILED',
        500,
        true
      );
    }
  }

  async generateWorkoutPlan(request, userId) {
    try {
      // Validate request
      const validationResult = validateWorkoutPlanRequest(request);
      if (!validationResult.isValid) {
        throw new GeminiServiceError(
          'Invalid workout plan request',
          'VALIDATION_ERROR',
          400,
          false,
          validationResult.errors
        );
      }

      const cacheKey = `workout_${JSON.stringify(request)}`;
      
      return await this.makeRequestWithRetry(
        async () => {
          const prompt = `Generate a ${request.difficulty} workout plan for ${request.duration} minutes. 
          Preferences: ${request.preferences.join(', ')}
          Restrictions: ${request.restrictions.join(', ')}
          
          Return a JSON object with the following structure:
          {
            "name": "Workout Name",
            "description": "Description",
            "duration": ${request.duration},
            "difficulty": "${request.difficulty}",
            "exercises": [
              {
                "name": "Exercise Name",
                "sets": 3,
                "reps": 10,
                "rest": 60,
                "notes": "Notes"
              }
            ],
            "equipment": ["equipment1", "equipment2"],
            "calories": 300,
            "ecoImpact": 5,
            "steps": ["step1", "step2"],
            "tips": ["tip1", "tip2"]
          }`;
          
          const content = await this.generateContent(prompt);
          return JSON.parse(content);
        },
        cacheKey,
        workoutPlanCache,
        userId
      );
    } catch (error) {
      logger.error('Error generating workout plan:', error);
      throw error;
    }
  }

  async generateActivityRecommendations(request, userId) {
    try {
      const validationResult = validateActivityRecommendationRequest(request);
      if (!validationResult.isValid) {
        throw new GeminiServiceError(
          'Invalid activity recommendation request',
          'VALIDATION_ERROR',
          400,
          false,
          validationResult.errors
        );
      }

      const cacheKey = `activity_${JSON.stringify(request)}`;
      
      return await this.makeRequestWithRetry(
        async () => {
          const prompt = `Generate activity recommendations for someone interested in: ${request.interests.join(', ')}
          Location: ${request.location}
          Available time: ${request.availableTime} minutes
          Current activities: ${request.currentActivities.join(', ')}
          
          Return a JSON object with the following structure:
          {
            "description": "Activity description",
            "ecoImpact": 8,
            "suggestions": ["suggestion1", "suggestion2"]
          }`;
          
          const content = await this.generateContent(prompt);
          return JSON.parse(content);
        },
        cacheKey,
        activityRecommendationCache,
        userId
      );
    } catch (error) {
      logger.error('Error generating activity recommendations:', error);
      throw error;
    }
  }

  async calculateEcoScore(request, userId) {
    try {
      const validationResult = validateEcoScoreRequest(request);
      if (!validationResult.isValid) {
        throw new GeminiServiceError(
          'Invalid eco score request',
          'VALIDATION_ERROR',
          400,
          false,
          validationResult.errors
        );
      }

      const cacheKey = `ecoscore_${JSON.stringify(request)}`;
      
      return await this.makeRequestWithRetry(
        async () => {
          const prompt = `Calculate an eco score based on the following data:
          Activities: ${JSON.stringify(request.activities)}
          Habits: ${JSON.stringify(request.habits)}
          Consumption: ${JSON.stringify(request.consumption)}
          
          Return a JSON object with the following structure:
          {
            "score": 75,
            "breakdown": [
              {
                "category": "Transportation",
                "score": 80,
                "suggestions": ["suggestion1", "suggestion2"]
              }
            ],
            "recommendations": ["rec1", "rec2"],
            "trends": [
              {
                "category": "Transportation",
                "trend": "improving",
                "percentage": 10
              }
            ]
          }`;
          
          const content = await this.generateContent(prompt);
          return JSON.parse(content);
        },
        cacheKey,
        ecoScoreCache,
        userId
      );
    } catch (error) {
      logger.error('Error calculating eco score:', error);
      throw error;
    }
  }

  async generateMealPlan(request, userId) {
    try {
      const validationResult = validateMealPlanRequest(request);
      if (!validationResult.isValid) {
        throw new GeminiServiceError(
          'Invalid meal plan request',
          'VALIDATION_ERROR',
          400,
          false,
          validationResult.errors
        );
      }

      const cacheKey = `mealplan_${JSON.stringify(request)}`;
      
      return await this.makeRequestWithRetry(
        async () => {
          const prompt = `Generate a meal plan with the following requirements:
          Dietary restrictions: ${request.dietaryRestrictions.join(', ')}
          Calorie goal: ${request.calorieGoal}
          Cuisine preferences: ${request.cuisine.join(', ')}
          Allergies: ${request.allergies.join(', ')}
          
          Return a JSON object with the following structure:
          {
            "name": "Meal Name",
            "description": "Description",
            "ingredients": ["ingredient1", "ingredient2"],
            "instructions": ["step1", "step2"],
            "nutritionalInfo": {
              "calories": 500,
              "protein": 25,
              "carbs": 45,
              "fat": 20
            },
            "ecoScore": 85,
            "carbonFootprint": 2.5
          }`;
          
          const content = await this.generateContent(prompt);
          return JSON.parse(content);
        },
        cacheKey,
        mealPlanCache,
        userId
      );
    } catch (error) {
      logger.error('Error generating meal plan:', error);
      throw error;
    }
  }
}

export const geminiService = new GeminiService();
export default geminiService; 