// This is a mock implementation for client-side use only
// In a real app, these operations would be performed on a server

// Simple UUID generator that works everywhere
function generateUUID() {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    const r = Math.random() * 16 | 0;
    const v = c === 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
}

// Mock user storage (this is only for demonstration purposes)
const users = [];

export async function createUser(userData) {
  // Check if user already exists
  const existingUser = users.find(user => user.email === userData.email);
  if (existingUser) {
    throw new Error('User with this email already exists');
  }
  
  // In a real app, we would hash the password here
  // For demo purposes, we're just storing it as plain text
  
  const now = new Date();
  const newUser = {
    ...userData,
    _id: generateUUID(),
    createdAt: now,
    updatedAt: now
  };
  
  // Add to our mock storage
  users.push(newUser);
  
  console.log('Created mock user:', newUser);
  
  return newUser;
}

export async function getUserByEmail(email) {
  return users.find(user => user.email === email) || null;
}

export async function validateUser(email, password) {
  const user = await getUserByEmail(email);
  
  if (!user) {
    return null;
  }
  
  // Skip password validation for social auth users
  if (user.provider) {
    return user;
  }
  
  // In a real app, we would compare hashed passwords
  // For demo purposes, we're just comparing plain text
  const isPasswordValid = user.password === password;
  
  if (!isPasswordValid) {
    return null;
  }
  
  return user;
} 