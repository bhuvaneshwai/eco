import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card } from '@/components/ui/card';
import { Leaf, Droplet, Bolt, Car, Bus, Bike, Footprints, AlertCircle, Loader2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { addActivity as apiAddActivity, getUserActivities } from '@/services/apiService';

const ActivityTracker = () => {
  const [activityType, setActivityType] = useState('');
  const [value, setValue] = useState('');
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [submitting, setSubmitting] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    const fetchActivities = async () => {
      try {
        setLoading(true);
        const response = await getUserActivities();
        setLogs(response.activities || []);
        setError(null);
      } catch (err) {
        setError('Failed to fetch activities. Please try again later.');
        toast({
          title: 'Error',
          description: 'Could not fetch recent activities.',
          variant: 'destructive',
        });
      } finally {
        setLoading(false);
      }
    };
    fetchActivities();
  }, [toast]);

  const getUnitForActivity = (type) => {
    switch (type) {
      case 'energy': return 'kWh';
      case 'water': return 'L';
      case 'transport': return 'km';
      default: return '';
    }
  };

  const handleAddActivity = async () => {
    if (!activityType || !value) {
      toast({
        title: 'Missing fields',
        description: 'Please select an activity type and enter a value.',
        variant: 'destructive',
      });
      return;
    }

    setSubmitting(true);
    try {
      const activityData = {
        activityType,
        value: parseFloat(value),
        unit: getUnitForActivity(activityType),
      };
      
      const newLog = await apiAddActivity(activityData);
      setLogs([newLog.activity, ...logs]);
      setActivityType('');
      setValue('');
      toast({
        title: 'Success!',
        description: 'Your activity has been logged.',
      });
    } catch (err) {
      setError('Failed to log activity. Please try again.');
      toast({
        title: 'Error',
        description: 'Could not log your activity.',
        variant: 'destructive',
      });
    } finally {
      setSubmitting(false);
    }
  };

  const getActivityIcon = (type) => {
    switch (type) {
      case 'energy': return <Bolt className="h-5 w-5" />;
      case 'water': return <Droplet className="h-5 w-5" />;
      case 'transport': return <Car className="h-5 w-5" />;
      default: return <Leaf className="h-5 w-5" />;
    }
  };

  return (
    <div className="space-y-6">
      <Card className="p-6">
        <h2 className="text-2xl font-bold">Daily Activity Tracker</h2>
        <p className="text-muted-foreground">Log your daily activities and track your eco-impact.</p>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">Activity Type</label>
            <Select value={activityType} onValueChange={setActivityType} disabled={submitting}>
              <SelectTrigger>
                <SelectValue placeholder="Select activity type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="energy">Energy Usage</SelectItem>
                <SelectItem value="water">Water Usage</SelectItem>
                <SelectItem value="transport">Transportation</SelectItem>
                <SelectItem value="food">Food Consumption</SelectItem>
                <SelectItem value="waste">Waste Production</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="space-y-2">
            <label className="text-sm font-medium">Value</label>
            <Input
              type="number"
              placeholder={`Enter value in ${getUnitForActivity(activityType)}`}
              value={value}
              onChange={(e) => setValue(e.target.value)}
              disabled={submitting}
            />
          </div>
        </div>
        
        <Button onClick={handleAddActivity} className="w-full mt-4" disabled={submitting}>
          {submitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Leaf className="mr-2 h-4 w-4" />}
          Log Activity
        </Button>
      </Card>

      <div className="space-y-4">
        <h3 className="text-xl font-semibold">Recent Activities</h3>
        {loading && (
          <div className="flex justify-center items-center p-8">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
          </div>
        )}
        {error && (
          <div className="text-red-500 flex items-center gap-2">
            <AlertCircle className="h-5 w-5" />
            <span>{error}</span>
          </div>
        )}
        {!loading && !error && logs.length === 0 && (
          <p className="text-muted-foreground">You haven't logged any activities yet.</p>
        )}
        {logs.map((log) => (
          <Card key={log._id} className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                {getActivityIcon(log.activityType)}
                <div>
                  <p className="font-medium capitalize">{log.activityType}</p>
                  <p className="text-sm text-muted-foreground">
                    {log.value} {log.unit}
                  </p>
                </div>
              </div>
              {log.carbonFootprint && (
                <div className="flex items-center space-x-2">
                  <Leaf className="h-5 w-5 text-eco-600" />
                  <span className="text-eco-600 font-medium">
                    {log.carbonFootprint.carbonKg.toFixed(2)} kg CO₂
                  </span>
                </div>
              )}
            </div>
            <p className="text-xs text-muted-foreground mt-2">
              {new Date(log.timestamp).toLocaleString()}
            </p>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default ActivityTracker; 