import React, { useState, useEffect } from 'react';
import { cn } from '@/lib/utils.js';
import { Button } from '@/components/ui/button';
import { Leaf, Menu, X, Moon, Sun, User, LogOut, Settings } from 'lucide-react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from "@/contexts/AuthContext";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useTheme } from "@/components/theme-provider";
import { UserAvatar } from "@/components/ui/user-avatar";

const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  const { user, userProfile, logout } = useAuth();
  const { theme, setTheme } = useTheme();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  const handleLogout = () => {
    logout();
    navigate("/");
  };

  const toggleTheme = () => {
    setTheme(theme === "dark" ? "light" : "dark");
  };

  const scrollToSection = (sectionId) => {
    console.log('Attempting to scroll to section:', sectionId);
    
    // Check if we're on the home page
    if (location.pathname !== '/') {
      console.log('Not on home page, navigating to home first');
      navigate('/');
      // Wait a bit for the page to load, then scroll
      setTimeout(() => {
        const element = document.getElementById(sectionId);
        if (element) {
          const navbarHeight = 80;
          const elementPosition = element.offsetTop - navbarHeight;
          window.scrollTo({
            top: elementPosition,
            behavior: 'smooth'
          });
        }
      }, 100);
      return;
    }
    
    const element = document.getElementById(sectionId);
    console.log('Found element:', element);
    if (element) {
      const navbarHeight = 80; // Approximate navbar height
      const elementPosition = element.offsetTop - navbarHeight;
      console.log('Scrolling to position:', elementPosition);
      window.scrollTo({
        top: elementPosition,
        behavior: 'smooth'
      });
    } else {
      console.log('Element not found for section:', sectionId);
      // List all elements with IDs to debug
      const allElements = document.querySelectorAll('[id]');
      console.log('All elements with IDs:', Array.from(allElements).map(el => el.id));
    }
  };

  return (
    <nav
      className={cn(
        'fixed top-0 left-0 right-0 z-50 transition-all duration-300 py-4 px-6',
        isScrolled
          ? 'glass shadow-sm backdrop-blur-lg'
          : 'bg-transparent'
      )}
    >
      <div className="container mx-auto">
        <div className="flex items-center justify-between">
          <Link to="/" className="flex items-center space-x-2">
            <Leaf className="h-8 w-8 text-eco-500" />
            <span className="text-2xl font-display font-bold bg-gradient-to-r from-eco-600 to-eco-400 bg-clip-text text-transparent">Eco-Navigator</span>
          </Link>

          {/* Desktop Navigation */}
          <ul className="hidden md:flex items-center space-x-8">
            <li>
              <button
                onClick={() => scrollToSection('features')}
                className="text-foreground/80 hover:text-eco-500 transition-colors font-medium"
              >
                Features
              </button>
            </li>
            <li>
              <button
                onClick={() => scrollToSection('stats')}
                className="text-foreground/80 hover:text-eco-500 transition-colors font-medium"
              >
                Impact
              </button>
            </li>
            <li>
              <button
                onClick={() => scrollToSection('testimonials')}
                className="text-foreground/80 hover:text-eco-500 transition-colors font-medium"
              >
                Testimonials
              </button>
            </li>
          </ul>

          {/* Theme Toggle */}
          <Button
            variant="ghost"
            size="icon"
            onClick={toggleTheme}
            className="text-gray-700 dark:text-gray-200 hover:text-eco-600 dark:hover:text-eco-400"
          >
            {theme === 'dark' ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
          </Button>

          {/* Auth Buttons / User Menu */}
          {user ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="relative h-8 w-8 rounded-full">
                  <UserAvatar 
                    src={userProfile?.avatar_url} 
                    alt={user.name || 'User'}
                    size="sm"
                    fallback={<User className="h-5 w-5 text-eco-600 dark:text-eco-400" />}
                  />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <div className="px-2 py-1.5 text-sm font-medium text-gray-700 dark:text-gray-200">
                  Hi, {user.name}
                </div>
                <DropdownMenuItem onClick={() => navigate("/profile")}>
                  <Settings className="mr-2 h-4 w-4" />
                  Profile Settings
                </DropdownMenuItem>
                <DropdownMenuItem onClick={handleLogout}>
                  <LogOut className="mr-2 h-4 w-4" />
                  Logout
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <div className="flex items-center space-x-4">
              <Link to="/login">
                <Button variant="ghost">Log in</Button>
              </Link>
              <Link to="/signup">
                <Button>Sign up</Button>
              </Link>
            </div>
          )}

          {/* Mobile Menu Button */}
          <button
            className="md:hidden text-foreground/80 hover:text-eco-500 transition-colors"
            onClick={toggleMobileMenu}
            aria-label="Toggle menu"
          >
            {isMobileMenuOpen ? (
              <X className="h-6 w-6" />
            ) : (
              <Menu className="h-6 w-6" />
            )}
          </button>
        </div>

        {/* Mobile Navigation */}
        <div
          className={cn(
            'fixed inset-x-0 bg-white/90 backdrop-blur-lg shadow-lg transition-all duration-300 ease-in-out md:hidden',
            isMobileMenuOpen
              ? 'top-16 opacity-100 visible'
              : 'top-[-100%] opacity-0 invisible'
          )}
        >
          <ul className="flex flex-col py-4 px-6 space-y-4">
            <li>
              <button
                onClick={() => {
                  scrollToSection('features');
                  setIsMobileMenuOpen(false);
                }}
                className="block py-2 text-foreground/80 hover:text-eco-500 transition-colors font-medium w-full text-left"
              >
                Features
              </button>
            </li>
            <li>
              <button
                onClick={() => {
                  scrollToSection('stats');
                  setIsMobileMenuOpen(false);
                }}
                className="block py-2 text-foreground/80 hover:text-eco-500 transition-colors font-medium w-full text-left"
              >
                Impact
              </button>
            </li>
            <li>
              <button
                onClick={() => {
                  scrollToSection('testimonials');
                  setIsMobileMenuOpen(false);
                }}
                className="block py-2 text-foreground/80 hover:text-eco-500 transition-colors font-medium w-full text-left"
              >
                Testimonials
              </button>
            </li>
            <li className="pt-2">
              <Button 
                className="w-full bg-eco-500 hover:bg-eco-600 text-white rounded-full transition-all"
                asChild
                onClick={() => setIsMobileMenuOpen(false)}
              >
                <Link to="/login">
                  Login
                </Link>
              </Button>
            </li>
            <li>
              <Button 
                variant="outline" 
                className="w-full border-eco-500 text-eco-500 hover:bg-eco-500/10 rounded-full transition-all"
                asChild
                onClick={() => setIsMobileMenuOpen(false)}
              >
                <Link to="/signup">
                  Sign Up
                </Link>
              </Button>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  );
};

export default Navbar; 