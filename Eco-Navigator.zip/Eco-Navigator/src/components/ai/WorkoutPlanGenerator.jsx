import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Dumbbell, Target, Clock, Flame, Heart, Leaf } from 'lucide-react';

const WorkoutPlanGenerator = () => {
  const [userProfile, setUserProfile] = useState({
    fitnessLevel: 'beginner',
    goals: [],
    availableDays: [],
    duration: 30,
    equipment: [],
    ecoPreferences: []
  });

  const [generatedPlan, setGeneratedPlan] = useState(null);
  const [isGenerating, setIsGenerating] = useState(false);

  const fitnessLevels = [
    { value: 'beginner', label: 'Beginner', description: 'New to fitness or returning after a break' },
    { value: 'intermediate', label: 'Intermediate', description: 'Regular exercise routine for 6+ months' },
    { value: 'advanced', label: 'Advanced', description: 'Consistent training for 2+ years' }
  ];

  const fitnessGoals = [
    { value: 'weight-loss', label: 'Weight Loss', icon: '⚖️' },
    { value: 'muscle-gain', label: 'Muscle Gain', icon: '💪' },
    { value: 'endurance', label: 'Endurance', icon: '🏃‍♂️' },
    { value: 'strength', label: 'Strength', icon: '🏋️‍♂️' },
    { value: 'flexibility', label: 'Flexibility', icon: '🧘‍♀️' },
    { value: 'eco-friendly', label: 'Eco-Friendly', icon: '🌱' }
  ];

  const availableEquipment = [
    { value: 'none', label: 'No Equipment', description: 'Bodyweight exercises only' },
    { value: 'minimal', label: 'Minimal', description: 'Resistance bands, dumbbells' },
    { value: 'home-gym', label: 'Home Gym', description: 'Full equipment available' },
    { value: 'outdoor', label: 'Outdoor', description: 'Park, trail access' }
  ];

  const ecoPreferences = [
    { value: 'outdoor-workouts', label: 'Outdoor Workouts', description: 'Prefer exercising outside' },
    { value: 'minimal-equipment', label: 'Minimal Equipment', description: 'Reduce resource consumption' },
    { value: 'sustainable-transport', label: 'Sustainable Transport', description: 'Walk/bike to workout locations' },
    { value: 'eco-friendly-supplements', label: 'Eco-Friendly Supplements', description: 'Plant-based nutrition' }
  ];

  const daysOfWeek = [
    { value: 'monday', label: 'Monday' },
    { value: 'tuesday', label: 'Tuesday' },
    { value: 'wednesday', label: 'Wednesday' },
    { value: 'thursday', label: 'Thursday' },
    { value: 'friday', label: 'Friday' },
    { value: 'saturday', label: 'Saturday' },
    { value: 'sunday', label: 'Sunday' }
  ];

  const handleGoalToggle = (goal) => {
    setUserProfile(prev => ({
      ...prev,
      goals: prev.goals.includes(goal)
        ? prev.goals.filter(g => g !== goal)
        : [...prev.goals, goal]
    }));
  };

  const handleDayToggle = (day) => {
    setUserProfile(prev => ({
      ...prev,
      availableDays: prev.availableDays.includes(day)
        ? prev.availableDays.filter(d => d !== day)
        : [...prev.availableDays, day]
    }));
  };

  const handleEquipmentToggle = (equipment) => {
    setUserProfile(prev => ({
      ...prev,
      equipment: prev.equipment.includes(equipment)
        ? prev.equipment.filter(e => e !== equipment)
        : [...prev.equipment, equipment]
    }));
  };

  const handleEcoPreferenceToggle = (preference) => {
    setUserProfile(prev => ({
      ...prev,
      ecoPreferences: prev.ecoPreferences.includes(preference)
        ? prev.ecoPreferences.filter(p => p !== preference)
        : [...prev.ecoPreferences, preference]
    }));
  };

  const generateWorkoutPlan = async () => {
    setIsGenerating(true);
    
    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const plan = createWorkoutPlan();
    setGeneratedPlan(plan);
    setIsGenerating(false);
  };

  const createWorkoutPlan = () => {
    const { fitnessLevel, goals, availableDays, duration, equipment, ecoPreferences } = userProfile;
    
    const workouts = {
      beginner: {
        cardio: ['Walking', 'Light Jogging', 'Cycling', 'Swimming'],
        strength: ['Bodyweight Squats', 'Push-ups', 'Planks', 'Lunges'],
        flexibility: ['Stretching', 'Yoga', 'Tai Chi', 'Pilates']
      },
      intermediate: {
        cardio: ['Running', 'HIIT', 'Cycling', 'Rowing'],
        strength: ['Squats', 'Deadlifts', 'Bench Press', 'Pull-ups'],
        flexibility: ['Dynamic Stretching', 'Yoga', 'Mobility Work']
      },
      advanced: {
        cardio: ['Sprint Intervals', 'Advanced HIIT', 'Endurance Training'],
        strength: ['Compound Lifts', 'Olympic Lifts', 'Advanced Variations'],
        flexibility: ['Advanced Yoga', 'Contortion', 'Mobility Mastery']
      }
    };

    const ecoWorkouts = [
      'Outdoor Running',
      'Trail Hiking',
      'Park Workouts',
      'Beach Training',
      'Forest Yoga',
      'Urban Cycling'
    ];

    const plan = {
      title: `${fitnessLevel.charAt(0).toUpperCase() + fitnessLevel.slice(1)} ${goals.join(' & ')} Plan`,
      duration: `${duration} minutes`,
      weeklySchedule: availableDays.map(day => ({
        day: day.charAt(0).toUpperCase() + day.slice(1),
        workout: generateDailyWorkout(workouts[fitnessLevel], goals, ecoPreferences, duration),
        ecoImpact: calculateEcoImpact(day, ecoPreferences)
      })),
      recommendations: generateRecommendations(goals, ecoPreferences),
      ecoScore: calculateOverallEcoScore(ecoPreferences)
    };

    return plan;
  };

  const generateDailyWorkout = (workoutTypes, goals, ecoPreferences, duration) => {
    const workout = {
      warmup: '5-10 minutes dynamic stretching',
      mainWorkout: [],
      cooldown: '5-10 minutes static stretching'
    };

    if (goals.includes('eco-friendly') || ecoPreferences.includes('outdoor-workouts')) {
      workout.mainWorkout.push('Outdoor cardio session');
    } else {
      workout.mainWorkout.push(workoutTypes.cardio[Math.floor(Math.random() * workoutTypes.cardio.length)]);
    }

    if (goals.includes('strength') || goals.includes('muscle-gain')) {
      workout.mainWorkout.push(workoutTypes.strength[Math.floor(Math.random() * workoutTypes.strength.length)]);
    }

    if (goals.includes('flexibility')) {
      workout.mainWorkout.push(workoutTypes.flexibility[Math.floor(Math.random() * workoutTypes.flexibility.length)]);
    }

    return workout;
  };

  const calculateEcoImpact = (day, ecoPreferences) => {
    let impact = 50; // Base impact
    
    if (ecoPreferences.includes('outdoor-workouts')) impact += 20;
    if (ecoPreferences.includes('minimal-equipment')) impact += 15;
    if (ecoPreferences.includes('sustainable-transport')) impact += 15;
    
    return Math.min(100, impact);
  };

  const calculateOverallEcoScore = (ecoPreferences) => {
    return Math.round((ecoPreferences.length / 4) * 100);
  };

  const generateRecommendations = (goals, ecoPreferences) => {
    const recommendations = [];
    
    if (goals.includes('eco-friendly')) {
      recommendations.push('Consider outdoor workouts to reduce gym energy consumption');
      recommendations.push('Use sustainable workout gear made from recycled materials');
    }
    
    if (ecoPreferences.includes('sustainable-transport')) {
      recommendations.push('Walk or bike to your workout location when possible');
    }
    
    if (ecoPreferences.includes('minimal-equipment')) {
      recommendations.push('Focus on bodyweight exercises to minimize equipment needs');
    }
    
    return recommendations;
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Dumbbell className="h-5 w-5" />
            Workout Plan Generator
          </CardTitle>
          <CardDescription>
            Create a personalized workout plan that aligns with your fitness goals and environmental values
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <Label>Fitness Level</Label>
              <Select value={userProfile.fitnessLevel} onValueChange={(value) => setUserProfile(prev => ({ ...prev, fitnessLevel: value }))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {fitnessLevels.map(level => (
                    <SelectItem key={level.value} value={level.value}>
                      {level.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label>Workout Duration (minutes)</Label>
              <Select value={userProfile.duration.toString()} onValueChange={(value) => setUserProfile(prev => ({ ...prev, duration: parseInt(value) }))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="15">15 minutes</SelectItem>
                  <SelectItem value="30">30 minutes</SelectItem>
                  <SelectItem value="45">45 minutes</SelectItem>
                  <SelectItem value="60">60 minutes</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div>
            <Label className="text-base font-medium">Fitness Goals</Label>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mt-2">
              {fitnessGoals.map(goal => (
                <div key={goal.value} className="flex items-center space-x-2">
                  <Checkbox
                    id={goal.value}
                    checked={userProfile.goals.includes(goal.value)}
                    onCheckedChange={() => handleGoalToggle(goal.value)}
                  />
                  <Label htmlFor={goal.value} className="flex items-center gap-2 cursor-pointer">
                    <span>{goal.icon}</span>
                    {goal.label}
                  </Label>
                </div>
              ))}
            </div>
          </div>

          <div>
            <Label className="text-base font-medium">Available Days</Label>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-2">
              {daysOfWeek.map(day => (
                <div key={day.value} className="flex items-center space-x-2">
                  <Checkbox
                    id={day.value}
                    checked={userProfile.availableDays.includes(day.value)}
                    onCheckedChange={() => handleDayToggle(day.value)}
                  />
                  <Label htmlFor={day.value} className="cursor-pointer">
                    {day.label}
                  </Label>
                </div>
              ))}
            </div>
          </div>

          <div>
            <Label className="text-base font-medium">Available Equipment</Label>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-2">
              {availableEquipment.map(equipment => (
                <div key={equipment.value} className="flex items-center space-x-2">
                  <Checkbox
                    id={equipment.value}
                    checked={userProfile.equipment.includes(equipment.value)}
                    onCheckedChange={() => handleEquipmentToggle(equipment.value)}
                  />
                  <Label htmlFor={equipment.value} className="cursor-pointer">
                    <div>
                      <div className="font-medium">{equipment.label}</div>
                      <div className="text-sm text-muted-foreground">{equipment.description}</div>
                    </div>
                  </Label>
                </div>
              ))}
            </div>
          </div>

          <div>
            <Label className="text-base font-medium flex items-center gap-2">
              <Leaf className="h-4 w-4" />
              Environmental Preferences
            </Label>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-2">
              {ecoPreferences.map(preference => (
                <div key={preference.value} className="flex items-center space-x-2">
                  <Checkbox
                    id={preference.value}
                    checked={userProfile.ecoPreferences.includes(preference.value)}
                    onCheckedChange={() => handleEcoPreferenceToggle(preference.value)}
                  />
                  <Label htmlFor={preference.value} className="cursor-pointer">
                    <div>
                      <div className="font-medium">{preference.label}</div>
                      <div className="text-sm text-muted-foreground">{preference.description}</div>
                    </div>
                  </Label>
                </div>
              ))}
            </div>
          </div>

          <Button 
            onClick={generateWorkoutPlan} 
            disabled={isGenerating || userProfile.goals.length === 0 || userProfile.availableDays.length === 0}
            className="w-full"
          >
            {isGenerating ? 'Generating Plan...' : 'Generate Workout Plan'}
          </Button>
        </CardContent>
      </Card>

      {generatedPlan && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Target className="h-5 w-5" />
              Your Personalized Workout Plan
            </CardTitle>
            <div className="flex items-center gap-4">
              <Badge variant="outline">
                <Clock className="h-3 w-3 mr-1" />
                {generatedPlan.duration}
              </Badge>
              <Badge className="bg-green-100 text-green-800">
                <Leaf className="h-3 w-3 mr-1" />
                Eco Score: {generatedPlan.ecoScore}%
              </Badge>
            </div>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-medium mb-3">Weekly Schedule</h4>
                <div className="space-y-3">
                  {generatedPlan.weeklySchedule.map((day, index) => (
                    <div key={index} className="p-3 border rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium">{day.day}</span>
                        <Badge variant="outline" className="text-xs">
                          Eco Impact: {day.ecoImpact}%
                        </Badge>
                      </div>
                      <div className="text-sm text-muted-foreground">
                        <div><strong>Warmup:</strong> {day.workout.warmup}</div>
                        <div><strong>Main:</strong> {day.workout.mainWorkout.join(', ')}</div>
                        <div><strong>Cooldown:</strong> {day.workout.cooldown}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <h4 className="font-medium mb-3">Recommendations</h4>
                <div className="space-y-2">
                  {generatedPlan.recommendations.map((rec, index) => (
                    <div key={index} className="p-3 bg-blue-50 rounded-lg">
                      <p className="text-sm">{rec}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="flex gap-2">
              <Button variant="outline">Save Plan</Button>
              <Button variant="outline">Export PDF</Button>
              <Button>Start Workout</Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default WorkoutPlanGenerator; 