import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { TrendingUp, Leaf, Target, Zap } from 'lucide-react';

const EcoScoreAnalyst = () => {
  const [ecoScore, setEcoScore] = useState(75);
  const [scoreHistory, setScoreHistory] = useState([]);
  const [categoryScores, setCategoryScores] = useState([
    { name: 'Transportation', score: 80, color: '#10B981' },
    { name: 'Diet', score: 70, color: '#F59E0B' },
    { name: 'Energy', score: 85, color: '#3B82F6' },
    { name: 'Waste', score: 65, color: '#EF4444' },
    { name: 'Water', score: 90, color: '#06B6D4' }
  ]);

  useEffect(() => {
    // Generate sample score history
    const history = Array.from({ length: 30 }, (_, i) => ({
      date: new Date(Date.now() - (29 - i) * 24 * 60 * 60 * 1000).toLocaleDateString(),
      score: Math.floor(Math.random() * 30) + 60
    }));
    setScoreHistory(history);
  }, []);

  const getScoreColor = (score) => {
    if (score >= 80) return 'text-green-600';
    if (score >= 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getScoreBadge = (score) => {
    if (score >= 80) return { text: 'Excellent', color: 'bg-green-100 text-green-800' };
    if (score >= 60) return { text: 'Good', color: 'bg-yellow-100 text-yellow-800' };
    return { text: 'Needs Improvement', color: 'bg-red-100 text-red-800' };
  };

  const recommendations = [
    {
      category: 'Transportation',
      tip: 'Consider carpooling or using public transport 2-3 times per week',
      impact: 'High',
      effort: 'Medium'
    },
    {
      category: 'Diet',
      tip: 'Reduce meat consumption by 1-2 meals per week',
      impact: 'Medium',
      effort: 'Low'
    },
    {
      category: 'Energy',
      tip: 'Switch to LED bulbs and unplug unused electronics',
      impact: 'Medium',
      effort: 'Low'
    },
    {
      category: 'Waste',
      tip: 'Start composting food waste and reduce single-use plastics',
      impact: 'High',
      effort: 'Medium'
    }
  ];

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Leaf className="h-5 w-5" />
            Eco Score Analysis
          </CardTitle>
          <CardDescription>
            Track your environmental impact and get personalized recommendations
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <div className="text-center">
              <div className={`text-4xl font-bold ${getScoreColor(ecoScore)}`}>
                {ecoScore}
              </div>
              <Badge className={getScoreBadge(ecoScore).color}>
                {getScoreBadge(ecoScore).text}
              </Badge>
              <p className="text-sm text-muted-foreground mt-2">Overall Score</p>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">+12</div>
              <p className="text-sm text-muted-foreground">Points this month</p>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">85</div>
              <p className="text-sm text-muted-foreground">Target Score</p>
            </div>
          </div>
          
          <Progress value={ecoScore} className="mb-4" />
          <p className="text-sm text-muted-foreground">
            You're {85 - ecoScore} points away from your target score
          </p>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Score History</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={scoreHistory}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="score" fill="#10B981" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Category Breakdown</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={categoryScores}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, score }) => `${name}: ${score}`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="score"
                >
                  {categoryScores.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="h-5 w-5" />
            Personalized Recommendations
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {recommendations.map((rec, index) => (
              <div key={index} className="p-4 border rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-medium">{rec.category}</h4>
                  <div className="flex gap-2">
                    <Badge variant="outline" className="text-xs">
                      Impact: {rec.impact}
                    </Badge>
                    <Badge variant="outline" className="text-xs">
                      Effort: {rec.effort}
                    </Badge>
                  </div>
                </div>
                <p className="text-sm text-muted-foreground">{rec.tip}</p>
                <Button size="sm" className="mt-3">
                  Learn More
                </Button>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Zap className="h-5 w-5" />
            Quick Actions
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Button variant="outline" className="h-20 flex-col">
              <TrendingUp className="h-5 w-5 mb-1" />
              <span className="text-xs">Track Activity</span>
            </Button>
            <Button variant="outline" className="h-20 flex-col">
              <Leaf className="h-5 w-5 mb-1" />
              <span className="text-xs">Set Goals</span>
            </Button>
            <Button variant="outline" className="h-20 flex-col">
              <Target className="h-5 w-5 mb-1" />
              <span className="text-xs">View Progress</span>
            </Button>
            <Button variant="outline" className="h-20 flex-col">
              <Zap className="h-5 w-5 mb-1" />
              <span className="text-xs">Get Tips</span>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default EcoScoreAnalyst; 