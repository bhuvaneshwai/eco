import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Utensils, Target, Clock, Leaf, Apple, ChefHat } from 'lucide-react';

const MealPlanGenerator = () => {
  const [userProfile, setUserProfile] = useState({
    dietaryPreferences: [],
    restrictions: [],
    goals: [],
    cookingTime: 'medium',
    servings: 2,
    ecoPreferences: []
  });

  const [generatedPlan, setGeneratedPlan] = useState(null);
  const [isGenerating, setIsGenerating] = useState(false);

  const dietaryPreferences = [
    { value: 'vegetarian', label: 'Vegetarian', icon: '🥬' },
    { value: 'vegan', label: 'Vegan', icon: '🌱' },
    { value: 'pescatarian', label: 'Pescatarian', icon: '🐟' },
    { value: 'mediterranean', label: 'Mediterranean', icon: '🫒' },
    { value: 'keto', label: 'Keto', icon: '🥑' },
    { value: 'paleo', label: 'Paleo', icon: '🥩' }
  ];

  const restrictions = [
    { value: 'gluten-free', label: 'Gluten Free', icon: '🌾' },
    { value: 'dairy-free', label: 'Dairy Free', icon: '🥛' },
    { value: 'nut-free', label: 'Nut Free', icon: '🥜' },
    { value: 'soy-free', label: 'Soy Free', icon: '🫘' },
    { value: 'low-sodium', label: 'Low Sodium', icon: '🧂' },
    { value: 'low-sugar', label: 'Low Sugar', icon: '🍯' }
  ];

  const nutritionGoals = [
    { value: 'weight-loss', label: 'Weight Loss', icon: '⚖️' },
    { value: 'muscle-gain', label: 'Muscle Gain', icon: '💪' },
    { value: 'energy-boost', label: 'Energy Boost', icon: '⚡' },
    { value: 'heart-health', label: 'Heart Health', icon: '❤️' },
    { value: 'digestive-health', label: 'Digestive Health', icon: '🫁' },
    { value: 'eco-friendly', label: 'Eco-Friendly', icon: '🌍' }
  ];

  const cookingTimes = [
    { value: 'quick', label: 'Quick (15-30 min)', description: 'Fast and easy meals' },
    { value: 'medium', label: 'Medium (30-60 min)', description: 'Balanced prep time' },
    { value: 'slow', label: 'Slow (60+ min)', description: 'Complex, flavorful dishes' }
  ];

  const ecoPreferences = [
    { value: 'local-ingredients', label: 'Local Ingredients', description: 'Support local farmers' },
    { value: 'seasonal-produce', label: 'Seasonal Produce', description: 'Use in-season fruits and vegetables' },
    { value: 'organic', label: 'Organic', description: 'Choose organic when possible' },
    { value: 'minimal-packaging', label: 'Minimal Packaging', description: 'Reduce plastic waste' },
    { value: 'plant-based', label: 'Plant-Based Focus', description: 'Prioritize plant proteins' },
    { value: 'zero-waste', label: 'Zero Waste', description: 'Use all parts of ingredients' }
  ];

  const handlePreferenceToggle = (category, value) => {
    setUserProfile(prev => ({
      ...prev,
      [category]: prev[category].includes(value)
        ? prev[category].filter(item => item !== value)
        : [...prev[category], value]
    }));
  };

  const generateMealPlan = async () => {
    setIsGenerating(true);
    
    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const plan = createMealPlan();
    setGeneratedPlan(plan);
    setIsGenerating(false);
  };

  const createMealPlan = () => {
    const { dietaryPreferences, restrictions, goals, cookingTime, servings, ecoPreferences } = userProfile;
    
    const mealPlan = {
      title: `${dietaryPreferences.join(' & ')} ${goals.join(' & ')} Meal Plan`,
      duration: '7 days',
      servings: servings,
      ecoScore: calculateEcoScore(ecoPreferences),
      weeklyPlan: generateWeeklyMeals(dietaryPreferences, restrictions, goals, cookingTime, ecoPreferences),
      shoppingList: generateShoppingList(),
      nutritionInfo: generateNutritionInfo(),
      ecoTips: generateEcoTips(ecoPreferences)
    };

    return mealPlan;
  };

  const generateWeeklyMeals = (dietaryPrefs, restrictions, goals, cookingTime, ecoPrefs) => {
    const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
    
    return days.map(day => ({
      day,
      breakfast: generateMeal('breakfast', dietaryPrefs, restrictions, goals, cookingTime, ecoPrefs),
      lunch: generateMeal('lunch', dietaryPrefs, restrictions, goals, cookingTime, ecoPrefs),
      dinner: generateMeal('dinner', dietaryPrefs, restrictions, goals, cookingTime, ecoPrefs),
      snacks: generateSnacks(dietaryPrefs, restrictions, ecoPrefs)
    }));
  };

  const generateMeal = (mealType, dietaryPrefs, restrictions, goals, cookingTime, ecoPrefs) => {
    const mealTemplates = {
      breakfast: {
        vegetarian: ['Oatmeal with Berries', 'Avocado Toast', 'Greek Yogurt Parfait'],
        vegan: ['Smoothie Bowl', 'Chia Pudding', 'Tofu Scramble'],
        mediterranean: ['Mediterranean Omelette', 'Feta and Olive Toast', 'Yogurt with Honey']
      },
      lunch: {
        vegetarian: ['Quinoa Salad', 'Vegetable Wrap', 'Lentil Soup'],
        vegan: ['Buddha Bowl', 'Chickpea Salad', 'Vegetable Curry'],
        mediterranean: ['Greek Salad', 'Falafel Wrap', 'Mediterranean Pasta']
      },
      dinner: {
        vegetarian: ['Stuffed Bell Peppers', 'Vegetable Stir Fry', 'Mushroom Risotto'],
        vegan: ['Cauliflower Steak', 'Black Bean Tacos', 'Vegetable Curry'],
        mediterranean: ['Grilled Fish', 'Mediterranean Chicken', 'Stuffed Grape Leaves']
      }
    };

    const primaryDiet = dietaryPrefs[0] || 'vegetarian';
    const meals = mealTemplates[mealType][primaryDiet] || mealTemplates[mealType]['vegetarian'];
    
    return {
      name: meals[Math.floor(Math.random() * meals.length)],
      prepTime: getPrepTime(cookingTime),
      ingredients: generateIngredients(primaryDiet, restrictions, ecoPrefs),
      instructions: generateInstructions(),
      nutrition: generateMealNutrition(goals),
      ecoImpact: calculateMealEcoImpact(ecoPrefs)
    };
  };

  const generateSnacks = (dietaryPrefs, restrictions, ecoPrefs) => {
    const snacks = [
      { name: 'Apple with Almond Butter', ecoFriendly: true },
      { name: 'Carrot Sticks with Hummus', ecoFriendly: true },
      { name: 'Mixed Nuts', ecoFriendly: true },
      { name: 'Greek Yogurt with Berries', ecoFriendly: false },
      { name: 'Dark Chocolate', ecoFriendly: false }
    ];

    return snacks.filter(snack => snack.ecoFriendly || !ecoPrefs.includes('plant-based')).slice(0, 2);
  };

  const generateIngredients = (diet, restrictions, ecoPrefs) => {
    const baseIngredients = [
      'Olive Oil', 'Garlic', 'Onion', 'Salt', 'Black Pepper'
    ];

    const dietSpecific = {
      vegetarian: ['Quinoa', 'Chickpeas', 'Spinach', 'Tomatoes', 'Avocado'],
      vegan: ['Tofu', 'Tempeh', 'Nutritional Yeast', 'Coconut Milk', 'Seeds'],
      mediterranean: ['Feta Cheese', 'Olives', 'Lemon', 'Herbs', 'Fish']
    };

    const ecoIngredients = ecoPrefs.includes('local-ingredients') ? ['Local Kale', 'Farm Fresh Eggs'] : [];
    const seasonalIngredients = ecoPrefs.includes('seasonal-produce') ? ['Seasonal Berries', 'Winter Squash'] : [];

    return [...baseIngredients, ...(dietSpecific[diet] || []), ...ecoIngredients, ...seasonalIngredients];
  };

  const generateInstructions = () => {
    return [
      'Prepare all ingredients as specified',
      'Heat oil in a large pan over medium heat',
      'Add aromatics and cook until fragrant',
      'Add main ingredients and cook until done',
      'Season to taste and serve hot'
    ];
  };

  const generateMealNutrition = (goals) => {
    const nutrition = {
      calories: Math.floor(Math.random() * 300) + 200,
      protein: Math.floor(Math.random() * 20) + 10,
      carbs: Math.floor(Math.random() * 30) + 20,
      fat: Math.floor(Math.random() * 15) + 5,
      fiber: Math.floor(Math.random() * 8) + 3
    };

    if (goals.includes('weight-loss')) {
      nutrition.calories = Math.min(nutrition.calories, 400);
    }
    if (goals.includes('muscle-gain')) {
      nutrition.protein = Math.max(nutrition.protein, 25);
    }

    return nutrition;
  };

  const getPrepTime = (cookingTime) => {
    const times = {
      quick: '15-30 minutes',
      medium: '30-60 minutes',
      slow: '60+ minutes'
    };
    return times[cookingTime] || times.medium;
  };

  const calculateEcoScore = (ecoPrefs) => {
    return Math.round((ecoPrefs.length / 6) * 100);
  };

  const calculateMealEcoImpact = (ecoPrefs) => {
    let impact = 50; // Base impact
    
    if (ecoPrefs.includes('local-ingredients')) impact += 15;
    if (ecoPrefs.includes('seasonal-produce')) impact += 10;
    if (ecoPrefs.includes('organic')) impact += 10;
    if (ecoPrefs.includes('plant-based')) impact += 15;
    
    return Math.min(100, impact);
  };

  const generateShoppingList = () => {
    return [
      { category: 'Produce', items: ['Spinach', 'Tomatoes', 'Avocado', 'Berries', 'Carrots'] },
      { category: 'Grains', items: ['Quinoa', 'Brown Rice', 'Whole Grain Bread'] },
      { category: 'Proteins', items: ['Chickpeas', 'Tofu', 'Greek Yogurt'] },
      { category: 'Pantry', items: ['Olive Oil', 'Garlic', 'Herbs', 'Nuts'] }
    ];
  };

  const generateNutritionInfo = () => {
    return {
      dailyCalories: 1800,
      protein: '80g',
      carbs: '200g',
      fat: '60g',
      fiber: '25g'
    };
  };

  const generateEcoTips = (ecoPrefs) => {
    const tips = [];
    
    if (ecoPrefs.includes('local-ingredients')) {
      tips.push('Visit your local farmer\'s market for fresh, local produce');
    }
    if (ecoPrefs.includes('seasonal-produce')) {
      tips.push('Choose seasonal fruits and vegetables to reduce transportation emissions');
    }
    if (ecoPrefs.includes('minimal-packaging')) {
      tips.push('Bring reusable bags and containers when shopping');
    }
    if (ecoPrefs.includes('zero-waste')) {
      tips.push('Use vegetable scraps to make homemade vegetable broth');
    }
    
    return tips;
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Utensils className="h-5 w-5" />
            Meal Plan Generator
          </CardTitle>
          <CardDescription>
            Create personalized meal plans that align with your dietary preferences and environmental values
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <Label>Cooking Time Preference</Label>
              <Select value={userProfile.cookingTime} onValueChange={(value) => setUserProfile(prev => ({ ...prev, cookingTime: value }))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {cookingTimes.map(time => (
                    <SelectItem key={time.value} value={time.value}>
                      {time.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label>Number of Servings</Label>
              <Select value={userProfile.servings.toString()} onValueChange={(value) => setUserProfile(prev => ({ ...prev, servings: parseInt(value) }))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1">1 serving</SelectItem>
                  <SelectItem value="2">2 servings</SelectItem>
                  <SelectItem value="4">4 servings</SelectItem>
                  <SelectItem value="6">6 servings</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div>
            <Label className="text-base font-medium">Dietary Preferences</Label>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mt-2">
              {dietaryPreferences.map(pref => (
                <div key={pref.value} className="flex items-center space-x-2">
                  <Checkbox
                    id={pref.value}
                    checked={userProfile.dietaryPreferences.includes(pref.value)}
                    onCheckedChange={() => handlePreferenceToggle('dietaryPreferences', pref.value)}
                  />
                  <Label htmlFor={pref.value} className="flex items-center gap-2 cursor-pointer">
                    <span>{pref.icon}</span>
                    {pref.label}
                  </Label>
                </div>
              ))}
            </div>
          </div>

          <div>
            <Label className="text-base font-medium">Dietary Restrictions</Label>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mt-2">
              {restrictions.map(restriction => (
                <div key={restriction.value} className="flex items-center space-x-2">
                  <Checkbox
                    id={restriction.value}
                    checked={userProfile.restrictions.includes(restriction.value)}
                    onCheckedChange={() => handlePreferenceToggle('restrictions', restriction.value)}
                  />
                  <Label htmlFor={restriction.value} className="flex items-center gap-2 cursor-pointer">
                    <span>{restriction.icon}</span>
                    {restriction.label}
                  </Label>
                </div>
              ))}
            </div>
          </div>

          <div>
            <Label className="text-base font-medium">Nutrition Goals</Label>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mt-2">
              {nutritionGoals.map(goal => (
                <div key={goal.value} className="flex items-center space-x-2">
                  <Checkbox
                    id={goal.value}
                    checked={userProfile.goals.includes(goal.value)}
                    onCheckedChange={() => handlePreferenceToggle('goals', goal.value)}
                  />
                  <Label htmlFor={goal.value} className="flex items-center gap-2 cursor-pointer">
                    <span>{goal.icon}</span>
                    {goal.label}
                  </Label>
                </div>
              ))}
            </div>
          </div>

          <div>
            <Label className="text-base font-medium flex items-center gap-2">
              <Leaf className="h-4 w-4" />
              Environmental Preferences
            </Label>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-2">
              {ecoPreferences.map(pref => (
                <div key={pref.value} className="flex items-center space-x-2">
                  <Checkbox
                    id={pref.value}
                    checked={userProfile.ecoPreferences.includes(pref.value)}
                    onCheckedChange={() => handlePreferenceToggle('ecoPreferences', pref.value)}
                  />
                  <Label htmlFor={pref.value} className="cursor-pointer">
                    <div>
                      <div className="font-medium">{pref.label}</div>
                      <div className="text-sm text-muted-foreground">{pref.description}</div>
                    </div>
                  </Label>
                </div>
              ))}
            </div>
          </div>

          <Button 
            onClick={generateMealPlan} 
            disabled={isGenerating || userProfile.dietaryPreferences.length === 0}
            className="w-full"
          >
            {isGenerating ? 'Generating Meal Plan...' : 'Generate Meal Plan'}
          </Button>
        </CardContent>
      </Card>

      {generatedPlan && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <ChefHat className="h-5 w-5" />
              Your Personalized Meal Plan
            </CardTitle>
            <div className="flex items-center gap-4">
              <Badge variant="outline">
                <Clock className="h-3 w-3 mr-1" />
                {generatedPlan.duration}
              </Badge>
              <Badge className="bg-green-100 text-green-800">
                <Leaf className="h-3 w-3 mr-1" />
                Eco Score: {generatedPlan.ecoScore}%
              </Badge>
              <Badge variant="outline">
                <Apple className="h-3 w-3 mr-1" />
                {generatedPlan.servings} servings
              </Badge>
            </div>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div>
                <h4 className="font-medium mb-3">Weekly Meal Plan</h4>
                <div className="space-y-4">
                  {generatedPlan.weeklyPlan.map((day, index) => (
                    <div key={index} className="p-4 border rounded-lg">
                      <h5 className="font-medium mb-2">{day.day}</h5>
                      <div className="space-y-2 text-sm">
                        <div><strong>Breakfast:</strong> {day.breakfast.name}</div>
                        <div><strong>Lunch:</strong> {day.lunch.name}</div>
                        <div><strong>Dinner:</strong> {day.dinner.name}</div>
                        <div><strong>Snacks:</strong> {day.snacks.map(s => s.name).join(', ')}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <h4 className="font-medium mb-3">Shopping List</h4>
                  <div className="space-y-2">
                    {generatedPlan.shoppingList.map((category, index) => (
                      <div key={index}>
                        <h6 className="font-medium text-sm">{category.category}</h6>
                        <p className="text-sm text-muted-foreground">{category.items.join(', ')}</p>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <h4 className="font-medium mb-3">Daily Nutrition</h4>
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div>Calories: {generatedPlan.nutritionInfo.dailyCalories}</div>
                    <div>Protein: {generatedPlan.nutritionInfo.protein}</div>
                    <div>Carbs: {generatedPlan.nutritionInfo.carbs}</div>
                    <div>Fat: {generatedPlan.nutritionInfo.fat}</div>
                  </div>
                </div>

                <div>
                  <h4 className="font-medium mb-3">Eco Tips</h4>
                  <div className="space-y-2">
                    {generatedPlan.ecoTips.map((tip, index) => (
                      <div key={index} className="p-2 bg-green-50 rounded text-sm">
                        {tip}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            <div className="flex gap-2">
              <Button variant="outline">Save Plan</Button>
              <Button variant="outline">Export PDF</Button>
              <Button>Start Cooking</Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default MealPlanGenerator; 