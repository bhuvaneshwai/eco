import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from 'recharts';
import { Calculator, TrendingUp, Leaf, Target, BarChart3, Loader2, AlertCircle, Save } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { calculateEcoScore as apiCalculateEcoScore, getCurrentEcoScore, getEcoScoreHistory } from '@/services/apiService';

const initialUserData = {
  transportation: { score: 50, details: { carMiles: 0, publicTransit: 0, walking: 0, cycling: 0 }},
  diet: { score: 50, details: { meatConsumption: 0, dairyConsumption: 0, localFood: 0, organicFood: 0 }},
  energy: { score: 50, details: { electricityUsage: 0, renewableEnergy: 0, heatingCooling: 0 }},
  waste: { score: 50, details: { recycling: 0, composting: 0, singleUsePlastics: 0 }},
  water: { score: 50, details: { dailyUsage: 0, conservation: 0 }},
};

const EcoScoreAnalyzer = () => {
  const [userData, setUserData] = useState(initialUserData);
  const [ecoScoreData, setEcoScoreData] = useState(null);
  const [scoreHistory, setScoreHistory] = useState([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState(null);
  const { toast } = useToast();

  const fetchLatestScore = useCallback(async () => {
    try {
      setLoading(true);
      const { ecoScore } = await getCurrentEcoScore();
      if (ecoScore) {
        setEcoScoreData(ecoScore);
        // Pre-fill userData form with latest score details
        const updatedUserData = { ...initialUserData };
        for (const category in ecoScore.categoryScores) {
          if (updatedUserData[category]) {
            updatedUserData[category].details = ecoScore.categoryScores[category].details;
          }
        }
        setUserData(updatedUserData);
      }
    } catch (err) {
      // It's okay if there's no score yet, don't show an error for 404
      if (err.response?.status !== 404) {
        setError('Failed to fetch your latest eco-score.');
      }
    } finally {
      setLoading(false);
    }
  }, []);

  const fetchScoreHistory = useCallback(async () => {
    try {
      const { scores } = await getEcoScoreHistory({ limit: 12 });
      const trend = scores.map(s => ({
        month: new Date(s.timestamp).toLocaleDateString('en-US', { month: 'short' }),
        score: s.overallScore,
        target: 80, // Example target
      })).reverse();
      setScoreHistory(trend);
    } catch (err) {
      setError('Failed to fetch your score history.');
    }
  }, []);

  useEffect(() => {
    fetchLatestScore();
    fetchScoreHistory();
  }, [fetchLatestScore, fetchScoreHistory]);

  const handleInputChange = (category, field, value) => {
    setUserData(prev => ({
      ...prev,
      [category]: {
        ...prev[category],
        details: {
          ...prev[category].details,
          [field]: parseFloat(value) || 0
        }
      }
    }));
  };

  const calculateCategoryScore = (category) => {
    // This is a simplified calculation for the UI, the real one is on the backend.
    // This part can be made more sophisticated to match the backend logic for instant feedback.
    let score = 50;
    if (category === 'transportation') {
      const { carMiles, publicTransit, walking, cycling } = userData.transportation.details;
      const total = carMiles + publicTransit + walking + cycling;
      if (total > 0) score = ((publicTransit + walking + cycling) / total) * 100;
    }
    return Math.max(0, Math.min(100, Math.round(score)));
  };

  const handleSubmit = async () => {
    setSubmitting(true);
    setError(null);
    try {
      const payload = {
        categoryScores: Object.entries(userData).reduce((acc, [key, value]) => {
          acc[key] = {
            score: calculateCategoryScore(key), // Frontend calculation for instant feedback
            details: value.details
          };
          return acc;
        }, {})
      };
      
      const { ecoScore: newScore } = await apiCalculateEcoScore(payload);
      setEcoScoreData(newScore);
      await fetchScoreHistory(); // Refresh history
      toast({
        title: 'Success!',
        description: `Your new eco-score is ${newScore.overallScore}.`,
      });
    } catch (err) {
      setError('Failed to calculate your eco-score. Please try again.');
      toast({
        title: 'Error',
        description: 'Could not save your eco-score.',
        variant: 'destructive',
      });
    } finally {
      setSubmitting(false);
    }
  };

  const getScoreColor = (score) => {
    if (score >= 80) return 'text-green-600';
    if (score >= 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getScoreBadge = (score) => {
    if (score >= 80) return { text: 'Excellent', color: 'bg-green-100 text-green-800' };
    if (score >= 60) return { text: 'Good', color: 'bg-yellow-100 text-yellow-800' };
    return { text: 'Needs Improvement', color: 'bg-red-100 text-red-800' };
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center p-8">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calculator className="h-5 w-5" />
            Eco Score Calculator
          </CardTitle>
          <CardDescription>
            Input your lifestyle data to calculate and track your environmental impact score.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* Form Inputs */}
            <div className="space-y-4">
              <h3 className="font-medium">Transportation</h3>
              {Object.keys(userData.transportation.details).map(field => (
                <div key={field}>
                  <Label htmlFor={`transportation-${field}`}>{field.replace(/([A-Z])/g, ' $1').trim()}</Label>
                  <Input id={`transportation-${field}`} type="number" value={userData.transportation.details[field]} onChange={e => handleInputChange('transportation', field, e.target.value)} disabled={submitting}/>
                </div>
              ))}
            </div>
            <div className="space-y-4">
              <h3 className="font-medium">Diet</h3>
              {Object.keys(userData.diet.details).map(field => (
                <div key={field}>
                  <Label htmlFor={`diet-${field}`}>{field.replace(/([A-Z])/g, ' $1').trim()}</Label>
                  <Input id={`diet-${field}`} type="number" value={userData.diet.details[field]} onChange={e => handleInputChange('diet', field, e.target.value)} disabled={submitting}/>
                </div>
              ))}
            </div>
             <div className="space-y-4">
              <h3 className="font-medium">Energy</h3>
              {Object.keys(userData.energy.details).map(field => (
                <div key={field}>
                  <Label htmlFor={`energy-${field}`}>{field.replace(/([A-Z])/g, ' $1').trim()}</Label>
                  <Input id={`energy-${field}`} type="number" value={userData.energy.details[field]} onChange={e => handleInputChange('energy', field, e.target.value)} disabled={submitting}/>
                </div>
              ))}
            </div>
            <div className="space-y-4">
              <h3 className="font-medium">Waste</h3>
               {Object.keys(userData.waste.details).map(field => (
                <div key={field}>
                  <Label htmlFor={`waste-${field}`}>{field.replace(/([A-Z])/g, ' $1').trim()}</Label>
                  <Input id={`waste-${field}`} type="number" value={userData.waste.details[field]} onChange={e => handleInputChange('waste', field, e.target.value)} disabled={submitting}/>
                </div>
              ))}
            </div>
             <div className="space-y-4">
              <h3 className="font-medium">Water</h3>
               {Object.keys(userData.water.details).map(field => (
                <div key={field}>
                  <Label htmlFor={`water-${field}`}>{field.replace(/([A-Z])/g, ' $1').trim()}</Label>
                  <Input id={`water-${field}`} type="number" value={userData.water.details[field]} onChange={e => handleInputChange('water', field, e.target.value)} disabled={submitting}/>
                </div>
              ))}
            </div>
          </div>
          <Button onClick={handleSubmit} className="w-full mt-6" disabled={submitting}>
            {submitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
            Calculate & Save Score
          </Button>
           {error && (
            <div className="mt-4 text-red-500 flex items-center gap-2">
              <AlertCircle className="h-5 w-5" />
              <span>{error}</span>
            </div>
          )}
        </CardContent>
      </Card>
      
      {/* Score Display */}
      {ecoScoreData && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2"><Leaf className="h-5 w-5" /> Your Eco Score</CardTitle>
          </CardHeader>
          <CardContent className="text-center">
            <div className={`text-6xl font-bold ${getScoreColor(ecoScoreData.overallScore)}`}>{ecoScoreData.overallScore}</div>
            <Badge className={`mt-2 ${getScoreBadge(ecoScoreData.overallScore).color}`}>{getScoreBadge(ecoScoreData.overallScore).text}</Badge>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mt-6 text-sm">
              {Object.entries(ecoScoreData.categoryScores).map(([category, { score }]) => (
                <div key={category}>
                  <div className="font-medium capitalize">{category}</div>
                  <div className={getScoreColor(score)}>{score}</div>
                  <Progress value={score} className="mt-1 h-2" />
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Trend Chart */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><TrendingUp className="h-5 w-5" /> Score History</CardTitle>
          <CardDescription>Your eco-score trend over the last 12 months.</CardDescription>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <AreaChart data={scoreHistory}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis domain={[0, 100]} />
              <Tooltip />
              <Area type="monotone" dataKey="score" stroke="#10B981" fill="#10B981" fillOpacity={0.3} />
              <Line type="monotone" dataKey="target" stroke="#F59E0B" strokeDasharray="5 5" />
            </AreaChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Recommendations */}
      {ecoScoreData?.recommendations?.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2"><Target className="h-5 w-5" /> Recommendations</CardTitle>
            <CardDescription>Personalized tips to improve your score.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {ecoScoreData.recommendations.map((rec, index) => (
              <div key={index} className="p-3 bg-muted/50 rounded-lg">
                <p className="font-semibold">{rec.tip}</p>
                <div className="flex items-center gap-4 text-sm text-muted-foreground mt-1">
                  <span>Category: <Badge variant="outline">{rec.category}</Badge></span>
                  <span>Impact: <Badge variant="outline">{rec.impact}</Badge></span>
                  <span>Effort: <Badge variant="outline">{rec.effort}</Badge></span>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default EcoScoreAnalyzer; 