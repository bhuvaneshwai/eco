import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Calendar, TrendingUp, Target, Activity } from 'lucide-react';

const ActivityTracker = () => {
  const [activities, setActivities] = useState([]);
  const [newActivity, setNewActivity] = useState({
    name: '',
    type: 'exercise',
    duration: '',
    calories: '',
    ecoImpact: 'low'
  });
  const [dailyGoal, setDailyGoal] = useState(30);
  const [weeklyProgress, setWeeklyProgress] = useState(0);

  useEffect(() => {
    // Load activities from localStorage
    const savedActivities = localStorage.getItem('activities');
    if (savedActivities) {
      setActivities(JSON.parse(savedActivities));
    }
  }, []);

  useEffect(() => {
    // Save activities to localStorage
    localStorage.setItem('activities', JSON.stringify(activities));
    
    // Calculate weekly progress
    const thisWeek = activities.filter(activity => {
      const activityDate = new Date(activity.date);
      const now = new Date();
      const weekStart = new Date(now.setDate(now.getDate() - now.getDay()));
      const weekEnd = new Date(weekStart);
      weekEnd.setDate(weekStart.getDate() + 6);
      return activityDate >= weekStart && activityDate <= weekEnd;
    });
    
    const totalMinutes = thisWeek.reduce((sum, activity) => sum + parseInt(activity.duration || 0), 0);
    const progress = Math.min((totalMinutes / (dailyGoal * 7)) * 100, 100);
    setWeeklyProgress(progress);
  }, [activities, dailyGoal]);

  const handleAddActivity = () => {
    if (!newActivity.name || !newActivity.duration) return;
    
    const activity = {
      ...newActivity,
      id: Date.now(),
      date: new Date().toISOString(),
      calories: parseInt(newActivity.calories) || 0,
      duration: parseInt(newActivity.duration)
    };
    
    setActivities([activity, ...activities]);
    setNewActivity({
      name: '',
      type: 'exercise',
      duration: '',
      calories: '',
      ecoImpact: 'low'
    });
  };

  const getEcoImpactColor = (impact) => {
    switch (impact) {
      case 'low': return 'bg-green-100 text-green-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'high': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getActivityIcon = (type) => {
    switch (type) {
      case 'exercise': return '🏃‍♂️';
      case 'yoga': return '🧘‍♀️';
      case 'cycling': return '🚴‍♂️';
      case 'swimming': return '🏊‍♂️';
      case 'walking': return '🚶‍♂️';
      default: return '⚡';
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="h-5 w-5" />
            Activity Tracker
          </CardTitle>
          <CardDescription>
            Track your daily activities and their environmental impact
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="activity-name">Activity Name</Label>
              <Input
                id="activity-name"
                value={newActivity.name}
                onChange={(e) => setNewActivity({...newActivity, name: e.target.value})}
                placeholder="e.g., Morning Run"
              />
            </div>
            <div>
              <Label htmlFor="activity-type">Activity Type</Label>
              <Select value={newActivity.type} onValueChange={(value) => setNewActivity({...newActivity, type: value})}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="exercise">Exercise</SelectItem>
                  <SelectItem value="yoga">Yoga</SelectItem>
                  <SelectItem value="cycling">Cycling</SelectItem>
                  <SelectItem value="swimming">Swimming</SelectItem>
                  <SelectItem value="walking">Walking</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="duration">Duration (minutes)</Label>
              <Input
                id="duration"
                type="number"
                value={newActivity.duration}
                onChange={(e) => setNewActivity({...newActivity, duration: e.target.value})}
                placeholder="30"
              />
            </div>
            <div>
              <Label htmlFor="calories">Calories Burned</Label>
              <Input
                id="calories"
                type="number"
                value={newActivity.calories}
                onChange={(e) => setNewActivity({...newActivity, calories: e.target.value})}
                placeholder="200"
              />
            </div>
            <div>
              <Label htmlFor="eco-impact">Environmental Impact</Label>
              <Select value={newActivity.ecoImpact} onValueChange={(value) => setNewActivity({...newActivity, ecoImpact: value})}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Low Impact</SelectItem>
                  <SelectItem value="medium">Medium Impact</SelectItem>
                  <SelectItem value="high">High Impact</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-end">
              <Button onClick={handleAddActivity} className="w-full">
                Add Activity
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Weekly Progress</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{Math.round(weeklyProgress)}%</div>
            <Progress value={weeklyProgress} className="mt-2" />
            <p className="text-xs text-muted-foreground mt-2">
              {Math.round(dailyGoal * 7)} minutes goal
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Today's Activities</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {activities.filter(a => new Date(a.date).toDateString() === new Date().toDateString()).length}
            </div>
            <p className="text-xs text-muted-foreground">
              Activities completed today
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Daily Goal</CardTitle>
            <Target className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{dailyGoal} min</div>
            <p className="text-xs text-muted-foreground">
              Target daily activity
            </p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Recent Activities</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {activities.slice(0, 10).map((activity) => (
              <div key={activity.id} className="flex items-center justify-between p-3 border rounded-lg">
                <div className="flex items-center gap-3">
                  <span className="text-2xl">{getActivityIcon(activity.type)}</span>
                  <div>
                    <p className="font-medium">{activity.name}</p>
                    <p className="text-sm text-muted-foreground">
                      {new Date(activity.date).toLocaleDateString()} • {activity.duration} min
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {activity.calories > 0 && (
                    <Badge variant="secondary">{activity.calories} cal</Badge>
                  )}
                  <Badge className={getEcoImpactColor(activity.ecoImpact)}>
                    {activity.ecoImpact} impact
                  </Badge>
                </div>
              </div>
            ))}
            {activities.length === 0 && (
              <p className="text-center text-muted-foreground py-8">
                No activities recorded yet. Start by adding your first activity!
              </p>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default ActivityTracker; 